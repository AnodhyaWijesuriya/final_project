import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { NameService } from './name.service';
import { Student,Faculty} from './user.model';
import { AngularFirestore } from '@angular/fire/compat/firestore';


@Component({
  selector: 'StudentmanagmentComponent',
  templateUrl: './studentmanagment.component.html',
 
  styleUrls: ['./studentmanagment.component.css']
})
export class StudentmanagmentComponent implements OnInit {
  
  btndashbord:string =""
  btnstudent:string=""
  btnproposal:string=""
  btnsupervisor:string=""
  btnguide:string=""
  btnexam:string=""
  dashComponent: boolean | undefined;
  superComponent:boolean | undefined;
  Student: Student[] | any;
  studenttable:any;
  studenteditformload: boolean | undefined;
  studentregform: boolean | undefined;
  studentForm: any;
  firstname:any;
  lastname:any;
  studentid:any;
  phonenumber:any;
  emailaddress:any;
  homeaddress:any;
  sintake:any;
  sfaculty:any;
  sdepartment:any;
  snumber:any;
  spwd:any;
  scpwd:any;
  deletusermodel:any;
  examinerComponent:any;
  //student search box
 searchText: string = "";
 studentcmp:any;
 proposalComponent:any;
 displayStyle:string= "none";
 textcolor = "white"
 guidlineComponent:any;


 public studentEditForm: FormGroup |any;
  userprofile: boolean | undefined;
  btnprofile: string | undefined;
 
  constructor(public firebaseService: NameService,public formBuilder: FormBuilder,private http:HttpClient,private angularFirestore: AngularFirestore
   ) { }

  ngOnInit(): void {
    this.btnstudent="#e2a500";
    this.dashComponent=false;
    this.textcolor = "white";
    this.superComponent=false;
    this.examinerComponent=false;
    this.proposalComponent=false;
    this.guidlineComponent=false;
    //this.studentsection()
    this.studenttable=true;
    this.studentcmp=true;
    this.firebaseService.getUserList().subscribe(res => {
      this.Student = res.map(e => {
        return {
          id: e.payload.doc.id,
          ...e.payload.doc.data() as {}
  
  
        } as Student;
      })
    })
  
  }

  backtotable(){
    this.studenttable=true;
    this.studentcmp=true;
    this.studentregform=false;
  }
  dashboardsection(){
    
    this.btndashbord="#e2a500";
    this.btnstudent="";
    this.btnproposal="";
    this.btnsupervisor="";
    this.btnguide="";
    this.btnexam="";
    this.dashComponent=true;
    this.studenttable=false;
    this.studentregform=false;
    this.studentcmp=false;
    this.examinerComponent=false;
    this.guidlineComponent=false;
  }

  studentsection(){
   this.studentcmp=true;
   this.studenttable=true;
   this.dashComponent=false;
   this.btndashbord="";
   this.btnstudent="#e2a500";
   this.btnproposal="";
   this.btnsupervisor="";
   this.btnguide="";
   this.btnexam="";
   this.studenteditformload=false;
   this.examinerComponent=false;
   this.guidlineComponent=false;
   this.firebaseService.getUserList().subscribe(res => {
    this.Student = res.map(e => {
      return {
        id: e.payload.doc.id,
        ...e.payload.doc.data() as {}


      } as Student;
    })
  })

  }

  proposalsection(){
   this.btndashbord="";
   this.btnstudent="";
   this.btnproposal="#e2a500";
   this.btnsupervisor="";
   this.btnguide="";
   this.btnexam="";
   this.studenttable=false;
   this.proposalComponent=true;
   this.dashComponent=false;
   this.studentcmp=false;
   this.examinerComponent=false;
   this.guidlineComponent=false;
  }

  loadsupervisor(){
   this.btndashbord="";
   this.btnstudent="";
   this.btnproposal="";
   this.btnsupervisor="#e2a500";
   this.btnguide="";
   this.btnexam=""; 
   this.examinerComponent=false;
   this.superComponent=true;
   this.studentcmp=false;
   this.studenttable=false;
   this.guidlineComponent=false;
   this.studentregform=false;
  }

  loadguid(){
   this.btndashbord="";
   this.btnstudent="";
   this.btnproposal="";
   this.btnsupervisor="";
   this.btnguide="#e2a500"; 
   this.btnexam="";
   this.studenttable=false;
   this.studentregform=false;
   this.studentcmp=false;
   this.examinerComponent=false;
  this.userprofile=false;
   this.guidlineComponent=true;
  }

  loadexaminer(){
   this.btndashbord="";
   this.btnstudent="";
   this.btnproposal="";
   this.btnsupervisor="";
   this.btnguide=""; 
   this.btnexam="#e2a500";
   this.examinerComponent=true;
   this.studentcmp=false;
   this.studenttable=false;
   this.guidlineComponent=false;
   this.studentregform=false;
  }

  loadprofile(){
    this.btndashbord="";
   this.btnstudent="";
   this.btnproposal="";
   this.btnsupervisor="";
   this.btnguide=""; 
   this.btnexam="";
   this.btnprofile="#e2a500";
   this.studenttable=false;
    this.studentregform=false;
    this.studentcmp=false;
    this.examinerComponent=false;
   this.userprofile=true;
   this.guidlineComponent=false;
  }

    //load student edit detail form
 
    loadstudentedit(student:any){
      
      this.studentregform=false;
      
      this.studenttable=false;
      this.studenteditformload=true;
      
     this.studentEditForm = this.formBuilder.group({
       
        fname :['',[Validators.required]],
        lname :['',[Validators.required]],
     
        phone :['',[Validators.required,Validators.pattern("^[0-9]*$")]],
        email:['',[Validators.required,Validators.email]],
       
        home:['',[Validators.required]],
        faculty:['',[Validators.required]],
        department:['',[Validators.required]],
        intake:['',[Validators.required]],
        num:['',[Validators.required]],
        password:['',[Validators.required]],
        conp:['',[Validators.required]],
    
      })
      this.firstname=student.fname;
      console.log('student firstname::',this.firstname);
      this.lastname=student.lname;
      this.studentid=student.id;
      this.phonenumber=student.phone;
      this.emailaddress=student.email;
      this.homeaddress= student.home;
      this.sfaculty=student.faculty;
      this.sintake=student.intake;
      this.sdepartment=student.department;
      this.snumber=student.num;
      this.spwd=student.password;
      this.scpwd=student.conp;
    }

    get fname(){
      return this.studentForm.get('fname');
    }
   
    get lname(){
     return this.studentForm.get('lname');
   }
   
    get password(){
     return this.studentForm.get('password');
   }
   
   get conp(){
     return this.studentForm.get('conp');
   }
   
   get email(){
     return this.studentForm.get('email');
   }
   
   get birthday(){
     return this.studentForm.get('birthday');
   }
   
   get home()
   {
     return this.studentForm.get('home');
   }
   
   get num(){
     return this.studentForm.get('num');
   }
   
   get phone(){
     return this.studentForm.get('phone');
   }

 

   onEditSubmit(){

  
    this.studentregform=false;
   
    this.studenteditformload=false;
    
this.firebaseService.updateStudent(this.studentEditForm.value, this.studentid);
//this.studentsection();
    this.studenttable=true;
  }

       //student search box
    //filter searchbox
filterCondition(User: any) {

  return User.num.toLowerCase().indexOf(this.searchText.toLowerCase()) != -1;
  
  }

   //load student form
 faculty:any;
 loadstudentform(){

  this.firebaseService.getfaculty().subscribe(res => {
    this.faculty = res.map(e => {
      return {
        id: e.payload.doc.id,
        ...e.payload.doc.data() as {}
  
  
      } as Faculty;
    })
  })
 
  this.studentregform=true;
 
  this.studenttable=false;

  
 this.studentForm = this.formBuilder.group({
   
    fname :['',[Validators.required]],
    lname :['',[Validators.required]],
    gender :['',[Validators.required]],
    phone :['',[Validators.required,Validators.pattern("^[0-9]*$")]],
    email:['',[Validators.required,Validators.email]],
    birthday:['',[Validators.required]],
    home:['',[Validators.required]],
    faculty:['',[Validators.required]],
    department:['',[Validators.required]],
    intake:['',[Validators.required]],
    num:['',[Validators.required]],
    password:['',[Validators.required,Validators.minLength(6)]],
    conp :['',[Validators.required]],

  })

 }

 deleteModalDialog(user:any){
  this.studentid=  user.id;
  console.log(user.id);
  this.deletusermodel=true;
  this.studenttable=false;
  this.displayStyle = "block";
}

deletestudent(){
  this.firebaseService.deleteStudent(this.studentid);
  this.studentsection();
  this.displayStyle = "none";
 }

closeModalDialog(){
  
  this.deletusermodel=false;
  this.studenttable=true;
  this.displayStyle = "none";
}

pwd:any;
cpwd:any;
 onSubmit(){ 
  console.log(this.pwd +''+ this.cpwd);
  if(this.pwd === this.cpwd){
    console.log("insert val", this.studentForm.value);
    this.firebaseService.onsendservice(this.studentForm.value);
    this.studentsection();
    this.studentregform=false;
  }
 else {
  
  //this.firebaseService.onsendservice(formData)
 
  alert('new password and confirmation password are not match');
  
  }
}

studentdob :any;
SendDataonChange(event: any) {
 this.studentdob=event.target.value;
 }

 facultyname:any;
 dep:any;
 getfacultyevent(event:any){
    this.facultyname= event.target.value;
   

    this.firebaseService.filterdep(this.facultyname).subscribe(res => {
      this.dep = res.map(e => {
        return {
          id: e.payload.doc.id,
          ...e.payload.doc.data() as {}
    
    
        } as Faculty;
      })
    })
 }

 intake:any
 getintake(event: any)
    {
     this.intake=event.target.value;
     console.log('this.intake',this.intake);
     this.searchbyintake(this.intake);


     }
   
 

 propintake:any;
  searchbyintake(intake:any){
   
    this.firebaseService.getStudentList(intake).subscribe(res => {
      this.Student = res.map(e => {
        return {
          id: e.payload.doc.id,
          ...e.payload.doc.data() as {}
  
  
        } as Student;
      })
    })
   // this.proposaltablesearch=true;
   // this.proposaltable=false;
  }


 
}
