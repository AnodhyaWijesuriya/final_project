import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { Observable } from 'rxjs';
import { AngularFireAuth } from '@angular/fire/compat/auth';
import { AngularFirestore } from '@angular/fire/compat/firestore';
import { Student,Proposal, Examiner } from './user.model';
import FirestoreFullTextSearch from 'firestore-full-text-search';
import {AppComponent} from './app.component';

@Injectable({
  providedIn: 'root'
})
export class NameService {

  data:any;
  isLoggedIn=false;


  constructor(private http:HttpClient,public auth:AngularFireAuth,private angularFirestore: AngularFirestore ) {

    
   }

   async signin(email:string,password:string)
       {
        
       await this.auth.signInWithEmailAndPassword(email,password).then(res=>{


             this.isLoggedIn=true;
             localStorage.setItem('user',JSON.stringify(res.user))
           
             })
      
   
      }



  onsendservice(student:Student){
    return new Promise<any>((resolve, reject) => {
      this.angularFirestore.collection('Student').add(student).then(response => {
        console.log(response)
      }, error => reject(error));
    });
    }

    onsendserviceexam(examiner:Examiner){
      return new Promise<any>((resolve, reject) => {
        this.angularFirestore.collection('Examiner').add(examiner).then(response => {
          console.log(response)
        }, error => reject(error));
      });
    }

    arrq:any|string[];
    onsendservice2(pro:Proposal){
      return new Promise<any>((resolve, reject) => {
        this.angularFirestore.collection('Proposal').add(pro).then(response => {
          console.log(response)
        }, error => reject(error));
      });
      }
    getUserList() {
      console.log("user set"+this.angularFirestore.collection('Student').snapshotChanges());
      return this.angularFirestore.collection('Student').snapshotChanges();
        
    }

    getExamList(){
      return this.angularFirestore.collection('Examiner').snapshotChanges();
    }

    getprosalList(year:any){
      console.log("user set"+this.angularFirestore.collection('Proposal',ref=>ref.where('date',"==",year)).snapshotChanges());
      return this.angularFirestore.collection('Proposal',ref=>ref.where('date',"==",year)).snapshotChanges();
    }

    onfilter(start:any , end:any){
      
     return this.angularFirestore.collection('Proposal',ref=>ref.limit(4).orderBy('title').startAt(start).endAt(end)).snapshotChanges();
     //this.angularFirestore.collection('Proposal',ref=>ref.(start,end,'hh').orderBy('title').startAt(start).endAt(end)).snapshotChanges();
    }

    ab:any;
    getrelated(currenttitle:any){
      console.log('mmmmm'+this.angularFirestore.collection("Proposal",ref=>ref.where('abstract',"array-contains",currenttitle)).snapshotChanges()._subscribe.toString());
      return (this.angularFirestore.collection("Proposal",ref=>ref.where('abstract',"array-contains",currenttitle)).snapshotChanges());
     // return (this.angularFirestore.collection("Proposal",ref=>ref.where('keywords',"array-contains",currenttitle)).snapshotChanges());
    }
   // console.log(FormData);
    //return this.http.post<any>('http://localhost/Test/Registration.php',fromData)
  

 /* onsenddelete(fromData:FormData):Observable<any>{
  
    return this.http.post<any>('http://localhost/Test/index1.php',fromData)
  }*/

  forgetpassword(user:any)

      {
           this.auth.sendPasswordResetEmail(user).then((res)=>{
           console.log("sent mail");
},(err:any)=>{
console.log("send not amail");

})
}
fullTextSearch:any;

updateStudent(student:Student,studentid:any){
  return this.angularFirestore.collection('Student').doc(studentid).update({
    fname :student.fname,
    lname :student.lname,
    gender :student.gender,
    phone :student.phone,
    email:student.email,
    birthday:student.birthday,
    home:student.home,
   

  });

}

deleteStudent(sid:any){
  return this.angularFirestore.collection('Student').doc(sid).delete();
  
  
 }
 newmasg:any
 sendtoapp(msg:any){
    console.log(msg);
     this.newmasg=msg;
    return this.newmasg.subscribe;
 }

 sendpropstatus(propstatus:any,propid:any){
  return this.angularFirestore.collection('Proposal').doc(propid).update({
    status :propstatus

  });
 }

 getpropde(title:any){
  return this.angularFirestore.collection("Proposal",ref=>ref.where('title',"==",title)).snapshotChanges();
 }

 assignex(ex:any){
  return this.angularFirestore.collection('Examiner',ref=>ref.where('name',"==",ex)).add({
    status :'Assign'

  });
 }

}
