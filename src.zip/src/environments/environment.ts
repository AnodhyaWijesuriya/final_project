// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  firebaseConfig : {

  apiKey: "AIzaSyAFr5vuw-0fmaNwcpRTjJf_32JRoAXWZ7M",
  authDomain: "research-management-19672.firebaseapp.com",
  projectId: "research-management-19672",
  storageBucket: "research-management-19672.appspot.com",
  messagingSenderId: "897756835872",
  appId: "1:897756835872:web:28871dd8cb866e686b4c45",
  measurementId: "G-78F6LG6QBX"
  
  }
  
  
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.
