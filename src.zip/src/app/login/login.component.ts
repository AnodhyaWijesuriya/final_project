import { Component, OnInit } from '@angular/core';
import { LoginService } from './login.service';

@Component({
  selector: 'LoginComponent',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  signmail: any;
  message: string | undefined;
  navdash: boolean = false;
  header: boolean | undefined;
  studenttable: boolean = false;
  stiles: boolean = false;
  studentregform: boolean = false;
  isSignedIn: boolean = false;
  error1: string | undefined;
  lognav: boolean = false;
  isSignedUp: boolean = false;
  isForgetPwd: boolean = false;
  fonts: string | undefined;
  isSignedin: boolean = false;
  registerComponent:boolean = false;
  loginComponent:any;
  dashComponent:any;
  disableSignIn:boolean=true;
  sidebarComponent:any;
  forgetpw:any;
  signIn:any;
  

  constructor(public firebaseService: LoginService) { }

  ngOnInit(): void {
    this.disableSignIn =true;
    if(localStorage.getItem('user')!==null){
      this.isSignedin=true;
      this.navdash = true;
      this.stiles = true;
      this.signIn=true;
      this.isForgetPwd= false;
    }else{
      this.isSignedin =false;
      this.studentregform = false;
    }
  }


  async onSignin(email:string,password:string)
  {
    this.signmail = email;
    await this.firebaseService.signin(email, password).then(() => {

      this.message = "You are logged"
      console.log(this.message);
      this.navdash=true;
      this.header = true;
      this.studenttable=false;
      this.stiles=true;
      this.studentregform=false;
      this.isSignedIn=false;
      this.error1="";
      this.dashComponent=true;
      this.disableSignIn=false;
     // this.sidebarComponent=true;
    }).catch((_error: any) => {

      this.error1 = "Incorrect Username or Password";
      console.log("error" + this.error1);
      this.isSignedIn=true;
      this.navdash=false;
      this.header = true;
      this.stiles=false;
      this.loginComponent=true;
      this.dashComponent=false;
    })
	  if(this.firebaseService.isLoggedIn)
	  this.isSignedIn=false;
    this.lognav=false;
    //this.navdash=true;
    this.isSignedUp = false;
    this.studentregform = false;
    this.signIn=false;
  }

  forgetpwd(){
    this.isForgetPwd= true;
    this.isSignedIn = false;
    this.isSignedUp = false;
    this.lognav=false;
    this.navdash=false;
    this.studentregform=false;
    this.fonts="100px";
   // this.forgetpw=true;
    this.signIn=false;
  
  }
  
  forget(emailSignUp1:string)
  
    {
     
        this.firebaseService.forgetpassword(emailSignUp1);
        this.isForgetPwd=false;
        this.isSignedIn = false;
        this.isSignedUp = false;
        this.lognav=false;
        this.navdash=false;
        this.studentregform=false;
        this.fonts="100px";
       // this.forgetpw=true;
        this.signIn=false;
        this.displayStyle = "block";
      
  
  
    }

   
    loadsignup(){
      this.registerComponent=true;
      this.disableSignIn=false;
    }

  displayStyle = "none";
  col="none";
  closePopup() {
      this.isSignedin=true;
      this.navdash = true;
      this.stiles = true;
      this.signIn=true;
      this.isForgetPwd= false;
      this.displayStyle = "none";
      this.signIn=true;
  }
}
