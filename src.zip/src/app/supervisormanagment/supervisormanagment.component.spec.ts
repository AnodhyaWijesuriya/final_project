import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SupervisormanagmentComponent } from './supervisormanagment.component';

describe('SupervisormanagmentComponent', () => {
  let component: SupervisormanagmentComponent;
  let fixture: ComponentFixture<SupervisormanagmentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SupervisormanagmentComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SupervisormanagmentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
