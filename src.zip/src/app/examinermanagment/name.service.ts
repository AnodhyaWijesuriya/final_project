import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { Observable } from 'rxjs';
import { AngularFireAuth } from '@angular/fire/compat/auth';
import { AngularFirestore } from '@angular/fire/compat/firestore';
import { Student,Proposal,Examiner} from './user.model';
import FirestoreFullTextSearch from 'firestore-full-text-search';

@Injectable({
  providedIn: 'root'
})
export class NameService {

  data:any;
  isLoggedIn=false;


  constructor(private http:HttpClient,public auth:AngularFireAuth,private angularFirestore: AngularFirestore ) {

    
   }

   


  onsendservice(examiner:Examiner){
    return new Promise<any>((resolve, reject) => {
      this.angularFirestore.collection('Examiner').add(examiner).then(response => {
        console.log(response)
      }, error => reject(error));
    });
    }

 

    getUserList() {
      console.log("user set"+this.angularFirestore.collection('Examiner').snapshotChanges());
      return this.angularFirestore.collection('Examiner').snapshotChanges();
        
    }

fullTextSearch:any;

updateExaminer(examiner:Examiner,examinerid:any){
  console.log(examiner);
  console.log(examinerid);
  return this.angularFirestore.collection('Examiner').doc(examinerid).update({
    fname :examiner.fname,
    lname :examiner.lname,
  
    phone :examiner.phone,
    email:examiner.email,
    aemail:examiner.aemail,
    home:examiner.home,
    password:examiner.apassword,
    conp:examiner.aconpw

  });

}

deleteExaminer(sid:any){
  return this.angularFirestore.collection('Examiner').doc(sid).delete();
  
  
 }
 newmasg:any
 sendtoapp(msg:any){
    console.log(msg);
     this.newmasg=msg;
    return this.newmasg.subscribe;
 }

 supervisorlist(){
  return this.angularFirestore.collection('Supervisoras').snapshotChanges();
 }

 acceptproposallist(){
  return this.angularFirestore.collection('Proposal',ref=>ref.where('status','==','Accept')).snapshotChanges();
 }

 assignex(ex:any,recordid:any,examinername:any,student:any){
 console.log('ex::'+JSON.stringify(ex),examinername,recordid);
  this.angularFirestore.collection('Examineras').add({
     // title:ex.title,
      sname:student,
      supervisor:ex.supervisor,
      examiner:ex.examiner.fname +' '+ex.examiner.lname,
      examineremail:ex.examiner.aemail,
      examstatus:'Assign',
      examdisablestatus:true
  });

  this.angularFirestore.collection('Proposal').doc(recordid).update({
    examinerstatus:'Assign',
    examdisablestatus:true,
    examiner:ex.examiner.fname +' '+ex.examiner.lname,
    examineremail:ex.examiner.aemail,
 });

 this.angularFirestore.collection('Examiner').doc(examinername).update({
  examinerstatus:'Assign'
});
 }

 getcurrentuser(){
  this.auth.currentUser.then(response => {
    console.log('current user'+response?.email);
  });
  
 }

 getfaculty(){
  return this.angularFirestore.collection('Faculty-dep').snapshotChanges();
 }

 filterdep(facultyname:any){
  return this.angularFirestore.collection('Faculty-dep').doc(facultyname).collection(facultyname).snapshotChanges();
 }
 

}
