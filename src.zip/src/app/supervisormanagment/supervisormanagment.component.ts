import { Component, OnInit } from '@angular/core';

import { NameService } from './name.service';
import { Supervisor,Proposal,Faculty,Requestdoc } from './user.model';
import { AngularFirestore } from '@angular/fire/compat/firestore';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';


@Component({
  selector: 'SupervisormanagmentComponent',
  templateUrl: './supervisormanagment.component.html',
  styleUrls: ['./supervisormanagment.component.css']
})
export class SupervisormanagmentComponent implements OnInit {
  supercomponent:boolean | undefined;
  btnsupervisor: string | undefined;
  dashComponent: boolean | undefined;
  examinerComponent: boolean | undefined;
  supervisortable: boolean | undefined;
  Supervisor: Supervisor[] | undefined;
  searchText: string = "";
  supercmp:any;
  proposalComponent:any;
  textcolor = "white";
  public supervisorForm: FormGroup |any;
  supervisordob: any;
  superregform:any;
  pwd:any;
  cpwd:any;
  aemail:any;
  studentComponent:any;
  displayStyle: string | undefined;
  deletusermodel: boolean | undefined;
  superid: any;
  superEditForm: FormGroup | any;
  supereditformload: boolean | undefined;
  firstname:any;
  lastname:any;
  studentid:any;
  phonenumber:any;
  emailaddress:any;
  homeaddress:any;
  sintake:any;
  sfaculty:any;
  sdepartment:any;
  snumber:any;
  saemail:any;
  spwd:any;
  scpwd:any;
  loadsupereditform: boolean | undefined;
  superComponent:any;
  superasForm:any;
  superassignForm:FormGroup | any;
  Proposal: any;
  Proposalc: any;
  Supervisor2: Supervisor[] | undefined;
  asform:any;
  userprofile: boolean | undefined;

  guidlineComponent:any;

  constructor(public firebaseService: NameService,public formBuilder: FormBuilder,private angularFirestore: AngularFirestore
    ) { }
 
   ngOnInit(): void {
     this.btnsupervisor="#e2a500";
     this.dashComponent=false;
     this.supercomponent=true;
     this.guidlineComponent=false;
    
     //this.proposalComponent=false;
    // this.studentComponent=false;
    // this.examinerComponent=false;
    
     //this.studentsection()
     this.supervisortable=true;
     this.textcolor = "white";
   // this.supereditformload=false;
   // this.loadsupereditform=false;
   // this.superasForm=false;
    this.supercmp=true;
     this.firebaseService.getUserList().subscribe(res => {
       this.Supervisor = res.map(e => {
         return {
           id: e.payload.doc.id,
           ...e.payload.doc.data() as {}
   
   
         } as Supervisor;
       })
     })
   
   }
 
   dashboardsection(){
     this.dashComponent=true;
     this.supervisortable=false;
     this.supercmp=false;
     this.superregform=false;
     this.supereditformload=false;
     this.loadsupereditform=false;
     this.superasForm=false;
     this.proposalComponent=false;
     this.studentComponent=false;
     this.examinerComponent=false;
     this.guidlineComponent=false;
     this.superrequestForm=false;
   }
 
   studentsection(){
    this.dashComponent=false;
     this.supervisortable=false;
     this.supercmp=false;
     this.superregform=false;
     this.studentComponent=true;
     this.supereditformload=false;
     this.loadsupereditform=false;
     this.superasForm=false;
     this.proposalComponent=false;
     this.examinerComponent=false;
     this.supercomponent=false;
     this.guidlineComponent=false;
     this.superrequestForm=false;
   }
 
   proposalsection(){
    this.dashComponent=false;
    this.supervisortable=false;
    this.supercmp=false;
    this.superregform=false;
    this.proposalComponent=true;
    this.supereditformload=false;
    this.loadsupereditform=false;
    this.superasForm=false;
    this.examinerComponent=false;
    this.studentComponent=false;
    this.guidlineComponent=false;
    this.superrequestForm=false;
   }
 
   loadsupervisor(){
    this.supercmp=true;
    this.btnsupervisor="#e2a500";
    this.dashComponent=false;
    this.supervisortable=true;
    this.superregform=false;
    this.supereditformload=false;
    this.loadsupereditform=false;
    this.superasForm=false;
    this.examinerComponent=false;
    this.studentComponent=false;
    this.proposalComponent=false;
    this.guidlineComponent=false;
    this.superrequestForm=false;
   }
 
   loadguid(){
    this.guidlineComponent=true;
    this.examinerComponent=false;
    this.supervisortable=false;
    this.superregform=false;
    this.supereditformload=false;
    this.loadsupereditform=false;
    this.supercmp=false;
    this.superasForm=false;
    this.studentComponent=false;
    this.proposalComponent=false;
    this.dashComponent=false;
   this.userprofile=false;
   this.superrequestForm=false;
   }
 
   loadexaminer(){
    this.examinerComponent=true;
    this.supervisortable=false;
    this.superregform=false;
    this.supereditformload=false;
    this.loadsupereditform=false;
    this.supercmp=false;
    this.superasForm=false;
    this.studentComponent=false;
    this.proposalComponent=false;
    this.dashComponent=false;
    this.guidlineComponent=false;
    this.superrequestForm=false;
    
   }

   loadprofile(){
    this.examinerComponent=false;
    this.supervisortable=false;
    this.superregform=false;
    this.supereditformload=false;
    this.loadsupereditform=false;
    this.supercmp=false;
    this.superasForm=false;
    this.studentComponent=false;
    this.proposalComponent=false;
    this.dashComponent=false;
   this.userprofile=true;
   this.guidlineComponent=false;
   this.superrequestForm=false;
  }
 
   faculty:any;
   loadsupervisorform(){
    this.superregform=true;
    this.supervisortable=false;
 
    this.supereditformload=false;
    this.loadsupereditform=false;

    this.firebaseService.getfaculty().subscribe(res => {
      this.faculty = res.map(e => {
        return {
          id: e.payload.doc.id,
          ...e.payload.doc.data() as {}
    
    
        } as Faculty;
      })
    })
    
  
 this.supervisorForm = this.formBuilder.group({
   
    fname :['',[Validators.required]],
    lname :['',[Validators.required]],
    stest:['',[Validators.required]],
    gender :['',[Validators.required]],
    stype:['',[Validators.required]],
    phone :['',[Validators.required,Validators.pattern("^[0-9]*$")]],
    email:['',[Validators.required,Validators.email]],
    birthday:['',[Validators.required]],
    home:['',[Validators.required]],
    faculty:['',[Validators.required]],
    department:['',[Validators.required]],
    aemail:['',[Validators.required,Validators.email]],
    password:['',[Validators.required,Validators.minLength(6)]],
    conp :['',[Validators.required]],

  })

   }

   deleteModalDialog(user:any){
    this.superid=  user.id;
    console.log(user.id);
    this.deletusermodel=true;
    this.supervisortable=false;
    this.displayStyle = "block";
  }
  
  deletesupervisor(){
    this.firebaseService.deleteSupervisor(this.superid);
    this.deletusermodel=false;
    this.supervisortable=true;
    this.displayStyle = "none";
   }
  
  closeModalDialog(){
    
    this.deletusermodel=false;
    this.supervisortable=true;
    this.displayStyle = "none";
  }

 loadsuperedit(supervisor:any){
  this.superregform=false;
  this.superid=  supervisor.id; 
  this.supervisortable=false;
  this.loadsupereditform=true;
  
 this.superEditForm = this.formBuilder.group({
   
    fname :['',[Validators.required]],
    lname :['',[Validators.required]],
 
    phone :['',[Validators.required,Validators.pattern("^[0-9]*$")]],
    email:['',[Validators.required,Validators.email]],
   
    home:['',[Validators.required]],
    aemail:['',[Validators.required,Validators.email]],
    
    faculty:['',[Validators.required]],
    department:['',[Validators.required]],
    password:['',[Validators.required]],
    conp:['',[Validators.required]],

  })
  this.firstname=supervisor.fname;
 // console.log('student firstname::',this.supervisor);
  this.lastname=supervisor.lname;
  this.superid=supervisor.id;
  this.phonenumber=supervisor.phone;
  this.emailaddress=supervisor.email;
  this.homeaddress= supervisor.home;
  this.sfaculty=supervisor.faculty;
  this.saemail=supervisor.aemail;
  console.log('gggg',supervisor.aemail);
  this.sdepartment=supervisor.department;
  this.snumber=supervisor.num;
  this.spwd=supervisor.password;
  this.scpwd=supervisor.conp;
 }

 filterCondition(User: any) {

  return User.fname.toLowerCase().indexOf(this.searchText.toLowerCase()) != -1;
  
  }

  get fname(){
    return this.supervisorForm.get('fname');
  }
 
  get stest(){
    return this.supervisorForm.get('stest');
  }

  get lname(){
   return this.supervisorForm.get('lname');
 }
 
  get password(){
   return this.supervisorForm.get('password');
 }
 
 get conp(){
   return this.supervisorForm.get('conp');
 }
 
 get email(){
   return this.supervisorForm.get('email');
 }
 
 get birthday(){
   return this.supervisorForm.get('birthday');
 }
 
 get home()
 {
   return this.supervisorForm.get('home');
 }
 
 get num(){
   return this.supervisorForm.get('num');
 }
 
 get phone(){
   return this.supervisorForm.get('phone');
 }

 get stype()
 {
   return this.supervisorForm.get('stype');
 }


  onSubmit(){ 
    
   console.log(this.supervisorForm.value);
     
      this.firebaseService.onsendservice(this.supervisorForm.value);
      this.loadsupervisor();
    }
  
  
  
  studentdob :any;
  SendDataonChange(event: any) {
   this.supervisordob=event.target.value;
   }

   onEditSubmit(){

    this.superrequestForm=false;
    this.superregform=false;
    this.supervisortable=false;
    this.supereditformload=false;
    
this.firebaseService.updateSupervisor(this.superEditForm.value, this.superid);
this.supervisortable=true;
this.loadsupereditform=false;
  }

   ti:any;
  loadassignsuper(){
    this.superasForm=true;
    this.supervisortable=false;
    this.supereditformload=false;
    this.superregform=false;
    this.superrequestForm=false;

    this.firebaseService.getUserListas().subscribe(res => {
      this.Supervisoras = res.map(e => {
        return {
          id: e.payload.doc.id,
          ...e.payload.doc.data() as {}
  
  
        } as Supervisor;
      })
    })
//accept proposal list
   this.firebaseService.getprosalList().subscribe(res => {
      this.Proposal = res.map(e => {
       
        return {
          id: e.payload.doc.id,
         
          ...e.payload.doc.data() as {}
  
  
        } as Proposal ;
      })
    })

    this.firebaseService.getUserList().subscribe(res => {
      this.Supervisor = res.map(e => {
        return {
          id: e.payload.doc.id,
          ...e.payload.doc.data() as {}
  
  
        } as Supervisor;
      })
    })

    this.firebaseService.getUserList2().subscribe(res => {
      this.Supervisor2 = res.map(e => {
        return {
          id: e.payload.doc.id,
          ...e.payload.doc.data() as {}
  
  
        } as Supervisor;
      })
    })

  }
/*  onSubmitassuper(){
    this.firebaseService.onsendservice2(this.superassignForm.value);
   // this.loadsupervisor();
   this.asform=false;
   this.superasForm=true;
  }*/
  
  selectedpro:any;
  getcurrenttitle(event:any){
    console.log('JJJ:'+event.target.value);
     this.ti=event.target.value;
    
     this.firebaseService.getstudent(this.ti).subscribe(res => {
      this.Proposalc = res.map(e => {
        this.selectedpro=e.payload.doc.id;
        return {
          id: e.payload.doc.id,
          
          ...e.payload.doc.data() as {}
  
  
        } as Proposal ;
      })
    });
  }

  Supervisoras:any;
  assignsuper(sup:any){
    console.log(sup.id);
   this.firebaseService.onsendserviceass(sup.id,this.selectedpro);
  
   this.firebaseService.getUserListas().subscribe(res => {
    this.Supervisoras = res.map(e => {
      return {
        id: e.payload.doc.id,
        ...e.payload.doc.data() as {}


      } as Supervisor;
    })
  })


  }

  facultyname:any;
  dep:any;
  getfacultyevent(event:any){
     this.facultyname= event.target.value;
    
 
     this.firebaseService.filterdep(this.facultyname).subscribe(res => {
       this.dep = res.map(e => {
         return {
           id: e.payload.doc.id,
           ...e.payload.doc.data() as {}
     
     
         } as Faculty;
       })
     })
  }


  //assign supervisor
proposal:any;
student:any;
supervisor:any;
proposalId:any;
coSupervisor2:any;
  getdetails(proposal:any){

    this.asform=true;
    this.superasForm=false;
    this.firebaseService.getUserList2().subscribe(res => {
      this.Supervisor2 = res.map(e => {
        
        return {
          id: e.payload.doc.id,
          ...e.payload.doc.data() as {}
  
  
        } as Supervisor;
      })
    })

    this.firebaseService.getcoUserList2().subscribe(res => {
      this.coSupervisor2 = res.map(e => {
        return {
          id: e.payload.doc.id,
          ...e.payload.doc.data() as {}
  
  
        } as Supervisor;
      })
    })

    this.superassignForm = this.formBuilder.group({
   
      title :['',[Validators.required]],
      sname :['',[Validators.required]],
      supervisor:['',[Validators.required]],
      cosupervisor:['',[Validators.required]]
     
  
    })

 this.proposal=proposal.title;
 // console.log('student firstname::',this.supervisor);
  this.student=proposal.student;
  this.supervisor=this.supervisor;
  this.proposalId=proposal.id; 
  }

  onAsSubmit(){
    this.firebaseService.onsendservice2(this.superassignForm.value,this.supperid,this.cosupperid,this.proposalId,this.supervisorname,this.cosupervisorname,this.scount,this.supervisoremail);
 /*   this.firebaseService.getUserList().subscribe(res => {
      this.Supervisor = res.map(e => {
        return {
          id: e.payload.doc.id,
          ...e.payload.doc.data() as {}
  
  
        } as Supervisor;
      })
    })*/

    this.asform=false;
    this.superasForm=true;
  }
 supperid:any;
 supervisorname:any;
 cosupervisorname:any='';
 cosupperid:any='';
 scount:any;
 supervisoremail:any;
  getsuper(event: any,supervisor:any)
    {
      this.supervisor=event.target.value;
      console.log('vvvvv',this.selectedLevel.scount);
      this.scount=this.selectedLevel.scount;
      this.supperid=this.selectedLevel.id;
      this.supervisorname=this.selectedLevel.fname + ' '+this.selectedLevel.lname
      this.supervisoremail=this.selectedLevel.aemail;
    }

    getcosuper(event: any,supervisor:any)
    {
      this.supervisor=event.target.value;
      console.log('vvvvv',this.selectedLevel2.id)
      this.cosupperid=this.selectedLevel2.id;
      this.cosupervisorname=this.selectedLevel2.fname + ' '+this.selectedLevel2.lname
      
    }

    selectedLevel:any;
    selectedLevel2:any;
     
    backtotable(){
    this.superregform=false;
    this.supervisortable=true;
    this.supereditformload=false;
    this.loadsupereditform=false;
    this.superasForm=false;
    this.asform=false;
    this.superrequestForm=false;
    }
    superrequestForm:any;
    requestdoc:any;
     loadrequestform(){
      this.superrequestForm=true;
      this.supervisortable=false;
      this.supereditformload=false;
      this.loadsupereditform=false;
      this.superasForm=false;

      this.firebaseService.getrequestList().subscribe(res => {
        this.requestdoc = res.map(e => {
          return {
            id: e.payload.doc.id,
            ...e.payload.doc.data() as {}
    
    
          } as Requestdoc;
        })
      })
     }

     
     acceptusermodel:any;
     requestid:any;
acc:any;

     acceptrequest(req:any){
      this.acceptusermodel=true;
      this.superrequestForm=false;
      this.supervisortable=false;
      this.supereditformload=false;
      this.loadsupereditform=false;
      this.superasForm=false;
      this.requestid=req.id;
     }

     acceptrequestform(){
      this.firebaseService.updaterequestsatus(this.requestid);

      this.acceptusermodel=false;
      this.superrequestForm=true;
      this.supervisortable=false;
      this.supereditformload=false;
      this.loadsupereditform=false;
      this.superasForm=false;
     }

     rejectusermodel:any;

     rejectrequest(req:any){
         
      this.rejectusermodel=true;
      this.acceptusermodel=false;
      this.superrequestForm=false;
      this.supervisortable=false;
      this.supereditformload=false;
      this.loadsupereditform=false;
      this.superasForm=false;
      this.requestid=req.id;

     }

     rejectrequestform(){
      this.firebaseService.updaterequestsatus2(this.requestid);
      this.rejectusermodel=false;
      this.acceptusermodel=false;
      this.superrequestForm=true;
      this.supervisortable=false;
      this.supereditformload=false;
      this.loadsupereditform=false;
      this.superasForm=false;
     }
   
}
