export class Student {
  id:string |any;
  fname :string | any;
  lname :string | any;
  gender :string | any;
  phone :string | any;
  email:string | any;
  birthday:string | any;
  home:string | any;
  faculty:string | any;
  department:string | any;
  intake:string | any;
  num:string | any;
  password:string | any;
  conp :string | any;
}

export class Proposal{
  id:string|any;
  title:string|any;
  supervisor:string|any;
  student:string|any;
  keywords:any;
  datep:any;
  abstract:any;
  status:any;
  disablestatus:any;
  url:string|any;
}

export class Examiner{
  id:string|any;
  name:string|any;
  designation:string|any;
  phone:string|any;
  faculty:string|any;
}

export class  Group{
  id:string|any;
  url:string|any;
}
export class  Budget{
  id:string|any;
  url:string|any;
  student:string|any;
  sid:string|any;
  title:string|any;
}

export class  Ethical{
  id:string|any;
  url:string|any;
  student:string|any;
  sid:string|any;
  title:string|any;
}

export class Monthlyprogrees{
id:string |any;
  examiner:string |any;
  student:string |any;
  month:string |any;
 // url:string|any;
  unable:string |any;
  supervisor:string |any;
  num:string |any;
  date:string |any;
  problem:string |any;
  planned:string |any;
  title:string |any;
  work:string |any;
}
