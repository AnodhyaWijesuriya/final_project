export class Student {
  id:string |any;
  fname :string | any;
  lname :string | any;
  gender :string | any;
  phone :string | any;
  email:string | any;
  birthday:string | any;
  home:string | any;
  faculty:string | any;
  department:string | any;
  intake:string | any;
  num:string | any;
  password:string | any;
  conp :string | any;
}

export class Proposal{
  id:string|any;
  title:string|any;
  supervisor:string|any;
  student:string|any;
  keywords:any;
}

export class Faculty{
  id:string|any;
  faculty:string|any;
  department:string|any;
}

export class Examiner{
  id:string|any;
  name:string|any;
  designation:string|any;
  phone:string|any;
  faculty:string|any;
}
