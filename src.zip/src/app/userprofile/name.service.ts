import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { Observable } from 'rxjs';
import { AngularFireAuth } from '@angular/fire/compat/auth';
import { AngularFirestore } from '@angular/fire/compat/firestore';

import FirestoreFullTextSearch from 'firestore-full-text-search';

@Injectable({
  providedIn: 'root'
})
export class NameService {

  data:any;
  isLoggedIn=false;


  constructor(private http:HttpClient,public auth:AngularFireAuth,private angularFirestore: AngularFirestore ) {

    
   }

currentemail:any;
userdetails:any;
 getcurrentuser(){
  this.auth.currentUser.then(response => {
    console.log('current user'+response?.email);
    this.currentemail=response?.email;
    this.userdetails=this.angularFirestore.collection('Admin',ref=>ref.where('email',"==",this.currentemail)).snapshotChanges();
    
  });
  return this.userdetails;
 }



getUser(useremail:any) {
 
  
  
  console.log(useremail);
  console.log("user set"+this.angularFirestore.collection('Admin',ref=>ref.where('email',"==",useremail)).snapshotChanges());
  return  this.angularFirestore.collection('Admin',ref=>ref.where('email',"==",useremail)).snapshotChanges();
    
}

editUser(userid:any,fname:string,lname:string,phone:string,address:string,faculty:string,department:string){
 
    return this.angularFirestore.collection('Admin').doc(userid).update({
      firstname:fname,
      lastname:lname,
      address:address,
      department:department,
      faculty:faculty,
      phone:phone
     
  
    });
  
  
}

 

}
