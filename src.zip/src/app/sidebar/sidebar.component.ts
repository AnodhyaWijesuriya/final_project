import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'SidebarComponent',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.css'],
  template: 'Say {{ message }}'
})
export class SidebarComponent implements OnInit {

  dashComponent:any;
  btndashbord:string =""
  btnstudent:string=""
  btnproposal:string=""
  btnsupervisor:string=""
  btnguide:string=""
  btnexam:string=""
  studentComponent:any;
  

  

  constructor() { }

  ngOnInit(): void {
    this.dashComponent=true;
    this.btndashbord="#e2a500";
    this.btnproposal="";
    
  }

  dashboardsection(){
    
     this.btndashbord="#e2a500";
     this.btnstudent="";
     this.btnproposal="";
     this.btnsupervisor="";
     this.btnguide="";
     this.btnexam="";
     //this.dashComponent=true;
 
   }

   studentsection(){
    this.btndashbord="";
    this.btnstudent="#e2a500";
    this.btnproposal="";
    this.btnsupervisor="";
    this.btnguide="";
    this.btnexam="";
    this.studentComponent=true;
    this.dashComponent=false;
   }

   proposalsection(){
    this.btndashbord="";
    this.btnstudent="";
    this.btnproposal="#e2a500";
    this.btnsupervisor="";
    this.btnguide="";
    this.btnexam="";
   }

   loadsupervisor(){
    this.btndashbord="";
    this.btnstudent="";
    this.btnproposal="";
    this.btnsupervisor="#e2a500";
    this.btnguide="";
    this.btnexam=""; 
   }

   loadguid(){
    this.btndashbord="";
    this.btnstudent="";
    this.btnproposal="";
    this.btnsupervisor="";
    this.btnguide="#e2a500"; 
    this.btnexam="";
   }

   loadexaminer(){
    this.btndashbord="";
    this.btnstudent="";
    this.btnproposal="";
    this.btnsupervisor="";
    this.btnguide=""; 
    this.btnexam="#e2a500";
   }

}
