import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { Observable } from 'rxjs';
import { AngularFireAuth } from '@angular/fire/compat/auth';
import { AngularFirestore } from '@angular/fire/compat/firestore';
import FirestoreFullTextSearch from 'firestore-full-text-search';


@Injectable({
  providedIn: 'root'
})
export class LoginService {

  data:any;
  isLoggedIn=false;


  constructor(private http:HttpClient,public auth:AngularFireAuth,private angularFirestore: AngularFirestore ) {

    
   }

   async signin(email:string,password:string)
       {
        
       await this.auth.signInWithEmailAndPassword(email,password).then(res=>{


             this.isLoggedIn=true;
             localStorage.setItem('user',JSON.stringify(res.user))
           
             })
      
   
      }

      forgetpassword(user:any)

      {
           this.auth.sendPasswordResetEmail(user).then((res)=>{
           console.log("sent mail");
},(err:any)=>{
console.log("send not amail");

})
}



 


}
