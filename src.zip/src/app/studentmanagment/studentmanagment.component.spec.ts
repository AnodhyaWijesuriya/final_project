import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StudentmanagmentComponent } from './studentmanagment.component';

describe('StudentmanagmentComponent', () => {
  let component: StudentmanagmentComponent;
  let fixture: ComponentFixture<StudentmanagmentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ StudentmanagmentComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(StudentmanagmentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
