import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'DashboardComponent',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  constructor() { }

  dashComponent:any;
  userprofile:any;
  btndashbord:string =""
  btnstudent:string=""
  btnproposal:string=""
  btnsupervisor:string=""
  btnguide:string=""
  btnexam:string=""
  btnprofile:string=""
  studentComponent:any;
  SidebarComponent: any ;
  sidebarComponent:any;
  proposalComponent:any;
  supervisorComponent:any;
  dash:any;
  nav:any;
  examinerComponent:any;
  guidlineComponent:any;

  ngOnInit(): void {
    this.dashComponent=true;
    this.btndashbord="#e2a500";
    this.dash=true;
    this.nav=true;
    this.btnexam="";
    this.supervisorComponent=false;
    this.proposalComponent=false;
    this.studentComponent=false;
    this.examinerComponent=false;
    this.guidlineComponent=false;
  }

  studentsection(){
    this.btndashbord="";
    this.btnstudent="#e2a500";
    this.btnproposal="";
    this.btnsupervisor="";
    this.btnguide="";
    this.btnexam="";
    this.btnprofile="";
    this.studentComponent=true;
    this.dashComponent=false;
    this.sidebarComponent=false;
    this.proposalComponent=false;
    this.examinerComponent=false;
    this.guidlineComponent=false;
    this.dash=false;
    this.nav=true;
   }

   dashboardsection(){
    
    this.btndashbord="#e2a500";
    this.btnstudent="";
    this.btnproposal="";
    this.btnsupervisor="";
    this.btnguide="";
    this.btnexam="";
    this.dash=true;
    this.nav=true;
    this.proposalComponent=false;
    this.studentComponent=false;
    this.examinerComponent=false;
    this.btnprofile="";
    this.guidlineComponent=false;

  }


  proposalsection2(){
   console.log('nnnnnnnnn'); 
   this.btndashbord="";
   this.btnstudent="";
   this.btnproposal="#e2a500";
   this.btnsupervisor="";
   this.btnguide="";
   this.btnexam="";
   this.proposalComponent=true;
   this.studentComponent=false;
   this.dashComponent=false;
   this.sidebarComponent=false;
   this.supervisorComponent=false;
   this.dash=false;
    this.nav=true;
    this.examinerComponent=false;
    this.guidlineComponent=false;
    this.btnprofile="";
  }

  loadsupervisor(){
   this.btndashbord="";
   this.btnstudent="";
   this.btnproposal="";
   this.btnsupervisor="#e2a500";
   this.btnguide="";
   this.btnexam=""; 
   this.supervisorComponent=true;
   this.proposalComponent=false;
   this.studentComponent=false;
   this.dashComponent=false;
   this.dash=false;
   this.nav=false;
   this.examinerComponent=false;
   this.guidlineComponent=false;
   this.btnprofile="";
  }

  loadguid(){
   this.btndashbord="";
   this.btnstudent="";
   this.btnproposal="";
   this.btnsupervisor="";
   this.btnguide="#e2a500"; 
   this.btnexam="";
   this.btnprofile="";
   this.examinerComponent=false;
   this.supervisorComponent=false;
   this.proposalComponent=false;
   this.studentComponent=false;
   this.dashComponent=false;
   this.guidlineComponent=true;
   this.dash=false;
   this.nav=false;
  }

  loadexaminer(){
   this.btndashbord="";
   this.btnstudent="";
   this.btnproposal="";
   this.btnsupervisor="";
   this.btnguide=""; 
   this.btnexam="#e2a500";
   this.examinerComponent=true;
   this.supervisorComponent=false;
   this.proposalComponent=false;
   this.studentComponent=false;
   this.dashComponent=false;
   this.guidlineComponent=false;
   this.dash=false;
   this.nav=false;
   this.btnprofile="";
  }

  loadprofile(){
    this.userprofile=true;
    this.examinerComponent=false;
   this.supervisorComponent=false;
   this.proposalComponent=false;
   this.studentComponent=false;
   this.dashComponent=false;
   this.guidlineComponent=false;
   this.btndashbord="";
   this.btnstudent="";
   this.btnproposal="";
   this.btnsupervisor="";
   this.btnguide=""; 
   this.btnexam="";
   this.btnprofile="#e2a500";
   this.dash=false;
   this.nav=false;
   
  }

}
