import { Component, OnInit,Inject, Injectable } from '@angular/core';
import { FormBuilder, FormGroup ,Validators } from '@angular/forms';
import { NameService } from './name.service';
import { Student , Proposal,Examiner } from './user.model';
import {HttpClient} from '@angular/common/http';
import { observable, Observable ,Subject,combineLatest, EMPTY} from 'rxjs';

import { AngularFirestore } from '@angular/fire/compat/firestore';
//import { analyzeAndValidateNgModules } from '@angular/compiler';
import { AngularFireStorage, AngularFireStorageReference, AngularFireUploadTask } from '@angular/fire/compat/storage';
import { finalize, isEmpty } from 'rxjs/operators';


import {NgbModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';
import { ifError } from 'assert';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent{


  loginComponent:boolean=true;


  closeResult:any;
  isSignedin=false
  isSignedIn = true
  isSignedUp = false
  signmail="sign"
  navdash =false
  lognav = true
  studentregform =false
  studenteditformload=false
  response='';
  studenttable=false
  supervisortable=false;
  header=false
  stiles=false
  btndashbord:string =""
  btnstudent: string =""
  textcolor:string=""
  public studentForm: FormGroup;
   
  public pForm: FormGroup;
  public examForm:FormGroup |any;
  public studentEditForm: FormGroup |any;
  public examasForm:FormGroup|any;
  datalist:any;
  fonts:any;
  isForgetPwd: any;
  proposaltable:any;
  mo=false;
  examinertable =false;
 
  supervisorregform = false;

  message = ""

 //student search box
 searchText: string = "";
 

  Student: Student[] | any;
  Proposal:Proposal[]|any;
  Examiner:Examiner[]|any;

 
  //@Input() text = "sss";
  //error: { name: string, message: string } = { name: "", message: "" }
 // error1: { name: string, message: string } = { name: "", message: "" }
 error1:any;

 //Filter realted details
 searchterm:any;
 startAt = new Subject();
 endAt = new Subject();

 startobs = this.startAt.asObservable();
 endobs = this.endAt.asObservable();
  Proposalx: Proposal[]|any;




  constructor(public firebaseService: NameService,public formBuilder: FormBuilder,private http:HttpClient,private angularFirestore: AngularFirestore,private af: AngularFireStorage,
    private modalService: NgbModal ){

    this.studentForm = this.formBuilder.group({
      fname :[''],
      lname :[''],
      gender :[''],
      phone :[''],
      email:[''],
      birthday:[''],
      home:[''],
      faculty:[''],
      department:[''],
      intake:[''],
      num:[''],
      password:[''],
      conp :['']
    
    })

    this. studentEditForm = this.formBuilder.group({
      fname :[''],
      lname :[''],
      gender :[''],
      phone :[''],
      email:[''],
      birthday:[''],
      home:[''],
      faculty:[''],
      department:[''],
      intake:[''],
      num:[''],
      password:[''],
      conp :['']
    
    })

    this.pForm = this.formBuilder.group({
      title:[''],
      keywords:[['ass','ggg']]
    })
  }
  
 title = 'Research_Management_System';
 ngOnInit()
{
  this.loginComponent=true;
  this.btndashbord="#e2a500"
  this.btnstudent=""
    if(localStorage.getItem('user')!==null){
      this.isSignedin=true;
      this.navdash = true;
      this.stiles = true;
    }else{
      this.isSignedin =false;
      this.studentregform = false;
    }
  //  this.checktitle(this.title);
  combineLatest([this.startobs,this.endobs]).subscribe((value)=>{
    this.firebaseService.onfilter(value[0],value[1]).subscribe((clubs)=>{
      this.clubs = clubs; 
      console.log('related list ::',this.clubs);
    })


})

} 




  SiginAgain() {

    this.isSignedIn = true;
    this.isSignedUp = false;
    this.lognav=true;
    this.navdash=false;
    this.studentregform=false;
    this.fonts="100px";
  }
 
  forget(emailSignUp1:string)
  
  {
   
      this.firebaseService.forgetpassword(emailSignUp1);



  }
  SigupAgain() {

    this.isSignedIn = false;
    this.isSignedUp = true;
    this.lognav=true;
    this.navdash=false;
    this.studentregform=false;
  }
 //load student form

 loadstudentform(){
  this.isSignedIn = false;
  this.isSignedUp = false;
  this.lognav=false;
  this.navdash=false;
  this.studentregform=true;
  this.header = true;
  this.navdash=true;
  this.studenttable=false;
  this.examinerForm=false;
  this.relatedproposaltable= false;
    this.supervisorregform = false;
 
    this.supervisortable =false;
  
 this.studentForm = this.formBuilder.group({
   
    fname :['',[Validators.required]],
    lname :['',[Validators.required]],
    gender :['',[Validators.required]],
    phone :['',[Validators.required,Validators.pattern("^[0-9]*$")]],
    email:['',[Validators.required,Validators.email]],
    birthday:['',[Validators.required]],
    home:['',[Validators.required]],
    faculty:['',[Validators.required]],
    department:['',[Validators.required]],
    intake:['',[Validators.required]],
    num:['',[Validators.required]],
    password:['',[Validators.required,Validators.minLength(6)]],
    conp :['',[Validators.required]],

  })

 }


 get fname(){
   return this.studentForm.get('fname');
 }

 get lname(){
  return this.studentForm.get('lname');
}

 get password(){
  return this.studentForm.get('password');
}

get conp(){
  return this.studentForm.get('conp');
}

get email(){
  return this.studentForm.get('email');
}

get birthday(){
  return this.studentForm.get('birthday');
}

get home()
{
  return this.studentForm.get('home');
}

get num(){
  return this.studentForm.get('num');
}

get phone(){
  return this.studentForm.get('phone');
}
propid:any;
btnproposal="";
 proposalsection(){
  
  this.supervisorregform = false;
  this.relatedproposaltable= false;
  this.supervisortable =false;
  this.examinerForm=false;
  this.examinerTable=false;
  this.studenttable=false;
  this.header=true;
  this.proposaltable=true;
  this.stiles = false;
  this.isSignedUp=false;
  this.btndashbord=""
  this.btnstudent=""
  this.textcolor = "white"
  this.btnproposal="#e2a500"
  this.studentregform=false;
  this.fonts="100px";
  const currentYear = new Date().getFullYear().toString();
 
  this.firebaseService.getprosalList(currentYear).subscribe(res => {
    this.Proposal = res.map(e => {
      this.propid=e.payload.doc.id;
      return {
        id: e.payload.doc.id,
       
        ...e.payload.doc.data() as {}


      } as Proposal ;
    })
  })


 }

 acceptpro:any;
 accept(){
 this.acceptpro="Accept";
 this.sendpropstatus();
 }

 reject(){
  this.acceptpro="Reject";
  this.sendpropstatus();
 }

 sendpropstatus(){
   this.firebaseService.sendpropstatus(this.acceptpro,this.propid);
 }

studentsection(){
  this.studenttable=true;
  this.header=true;
  this.stiles = false;
  this.isSignedUp=false;
  this.btndashbord=""
  this.btnstudent="#e2a500"
  this.textcolor = "white"
  this.studentregform=false;
  this.fonts="100px";
  this.examinerForm=false;
  this.examinerTable=false;
  this.relatedproposaltable= false;
  this.firebaseService.getUserList().subscribe(res => {
    this.Student = res.map(e => {
      return {
        id: e.payload.doc.id,
        ...e.payload.doc.data() as {}


      } as Student;
    })
  })
  
  /*this.http.get<any>('http://localhost/Test/Registration.php').subscribe(data=>{
       
      //this.data.push(data);
   
      //this.response=data;
            //"Lokesh" 37 "Raj" 35 "John" 40
      this.datalist=data;
      
      console.log('bbbbb',this.datalist);
    },error=>console.error(error));*/
}
clubs :any;
relatedproposaltable:any;
checktitle(title:any){
  
  console.log(title);
  this.startAt.next(title);
  this.endAt.next(title +"\uf8ff");
  console.log('llllll',this.startAt.next(title));
  console.log('kkkkk',this.endAt.next(title +"\uf8ff"));
  
 
  
  this.relatedproposaltable= true;
  this.navdash=true;
  this.header = true;
  this.studenttable=false;
  this.stiles=false;
  this.btndashbord="#e2a500"
  this.btnstudent=""
  this.studentregform=false;
  this.proposaltable=true;

  
 // this.firebaseService.onfilter(title);
}

search:any;
searchtitle(title:any){
  this.search=title;
  this.relatedproposaltable= true;
  this.navdash=true;
  this.header = true;
  this.studenttable=false;
  this.stiles=false;
  this.btndashbord=""
  this.btnstudent=""
  this.studentregform=false;
  this.proposaltable=false;

 // this.fultext();
  this.mm();
}


searcmh(event:any){
  let se = event.target.value;
  console.log('se:'+se);
  this.startAt.next(se);
  this.endAt.next(se +"\uf8ff");

}


test(value:any)
{this.firebaseService.onfilter(value[0],value[1]).subscribe((clubs)=>{
  this.clubs = clubs; 
  console.log('related list ::',this.clubs);
})
}
dashboardsection(){
 this.navdash=true;
  this.header = true;
  this.studenttable=false;
  this.stiles=true;
this.btndashbord="#e2a500"
this.btnstudent=""
  this.studentregform=false;
  this.examinerForm=false;
  this.examinerTable=false;
  this.relatedproposaltable= false;
}

 studentdob :any;
 SendDataonChange(event: any) {
  this.studentdob=event.target.value;
  }

pwd:any;
cpwd:any;
 onSubmit(){ 
  console.log(this.pwd +''+ this.cpwd);
  if(this.pwd === this.cpwd){
    console.log("insert val", this.studentForm.value);
  }
 else {
  this.firebaseService.onsendservice(this.studentForm.value);
  //this.firebaseService.onsendservice(formData)
 
  alert('passwords are not match');
  this.studentsection();
  }
}




  arrq:any;
  i:any;
  arrtitle:any|string[];
  currenttitle:any;
   arr: Object[] = [];



  fultext(){
   // this.uploadproposal=true;
    //console.log('gggg');
   // this.arrq=['test'];
   // this.arrtitle=['title'];
   console.log( this.search);
   this.currenttitle=this.search;
   
    //console.log(this.arrq.length);
   /* this.angularFirestore.collection("Proposal").ref.get().then(function(querySnapshot) {
      querySnapshot.forEach(function(doc) {
          // doc.data() is never undefined for query doc snapshots
          console.log(doc.id, " => ", doc.data());
      });
  })
  .catch(function(error) {
      console.log("Error getting documents: ", error);
  });*/
  
 
   // this.angularFirestore.collection("Proposal").ref.where('keywords',"array-contains",this.currenttitle).get().then(function(querySnapshot) {
      this.angularFirestore.collection("Proposal").ref.where('keywords',"array-contains",this.currenttitle).get().then((querySnapshot) => {
     // querySnapshot.forEach(function(doc) {
      querySnapshot.forEach((doc) => {
          // doc.data() is never undefined for query doc snapshots
         // console.log(doc.id, " => ", (doc.data().title));
          this.arr.push(doc);
          //console.log(this.clubs);
      });
  })
  .catch(function(error) {
      console.log("Error getting documents: ", error);
  });
  
    
      
   }
proposalx:any;
pp:any;
   mm(){
    // this.clubs=this.clubs;
     console.log('bbbbbbbb'+this.arr.pop());
     
     this.firebaseService.getrelated('test').subscribe(res => {
      console.log('oooooo'+res.keys);
    
      this.Proposalx = res.map(e => {
        this.pp='res';
        console.log('oooooo'+e.payload.doc.id);
        return {
          id: e.payload.doc.id,
          ...e.payload.doc.data() as {}
  
  
        } as Proposal;
      })
    
    })

    if(this.pp !='res'){

    }
  
   }

   //Get URL uploaded image from firestorage
public uploadFile(event: any): void {




  var n = Date.now();
  const file = event.target.files[0];
  const filePath = 'proposal/'+file.name;
  const fileRef = this.af.ref(filePath);
  const task = this.af.upload('proposal/'+file.name, file);
  task
    .snapshotChanges()
    .pipe( finalize(() => {
        fileRef.getDownloadURL().subscribe(downloadURL => {
          console.log(downloadURL);
          
          this.geturl(downloadURL);
         
        });
      })
    )
    .subscribe();
    
  }
  
  pic:any;
  geturl(cc: any) {
    this.pic = cc;
    console.log("pic", this.pic);
    }

    uploadproposal:any;

    uploadproposalm(){
      this.uploadproposal=true;
      this.studenttable=false;
      this.header=true;
      this.proposaltable=true;
      this.stiles = false;
      this.isSignedUp=false;
      this.btndashbord=""
      this.btnstudent="#e2a500"
      this.textcolor = "white"
      this.studentregform=false;
      this.fonts="100px";
    }

  /*  opendialog(){
     
      this.dialogRef.open(PopUpComponent);
    }*/
   arrayh:any;
  
    onSubmitp(bb:any){
      console.log('kkkk'+bb);
     
       console.log('nnn'+this.pForm.value);
      // this.firebaseService.onsendservice2(this.pForm.value);
    }

    //student search box
    //filter searchbox
filterCondition(User: any) {

  return User.num.toLowerCase().indexOf(this.searchText.toLowerCase()) != -1;
  
  }


  firstname:any;
  lastname:any;
  studentid:any;
  phonenumber:any;
  emailaddress:any;
  homeaddress:any;
  sintake:any;
  sfaculty:any;
  sdepartment:any;
  snumber:any;
  //student edit details submit to db
  onEditSubmit(){

    this.isSignedIn = false;
    this.isSignedUp = false;
    this.lognav=false;
    this.navdash=false;
    this.studentregform=false;
    this.header = true;
    this.navdash=true;
    this.studenttable=false;
    this.studenteditformload=false;

this.firebaseService.updateStudent(this. studentEditForm.value, this.studentid);
this.studentsection();
  }

  data:any;
 
  loadstudentdelete(student:any){
    
   /* this.studenttable=false;
    this.dialogRef.open(PopUpComponent,{data:{
      studentlistid:student.id,
      studentname:student.fname + ' '+student.lname
    }});*/
    
    //this.pop.deletestudet(student);
   
    }

 closedialog(){
   this.studentsection();
 }

 deletestudent(){
  this.firebaseService.deleteStudent(this.studentid);
  this.studentsection();
 }

closeModalDialog(user:any){
  this.studentid=  user.id;
console.log(user.id);
this.mo=true;
this.studenttable=false;
}


loadsupervisor()
{
  this.supervisortable =true;
  this.isSignedIn = false;
    this.isSignedUp = false;
    this.lognav=false;
    this.navdash=false;
    this.studentregform=false;
    this.header = true;
    this.navdash=true;
    this.studenttable=false;
    this.studenteditformload=false;
    this.stiles = false;
    this.supervisorregform = false;
}

loadexaminer()
{
  this.examinertable =true;
  this.supervisortable =false;
  this.isSignedIn = false;
    this.isSignedUp = false;
    this.lognav=false;
    this.navdash=false;
    this.studentregform=false;
    this.header = true;
    this.navdash=true;
    this.studenttable=false;
    this.studenteditformload=false;
    this.stiles = false;
}

loadsupervisorform(){
  this.supervisorregform = true;
  this.examinertable =false;
  this.supervisortable =false;
  this.isSignedIn = false;
    this.isSignedUp = false;
    this.lognav=false;
    this.navdash=false;
    this.studentregform=false;
    this.header = true;
    this.navdash=true;
    this.studenttable=false;
    this.studenteditformload=false;
    this.stiles = false;
    this.loadexaminer();
}







displayStyle = "none";
  col="none";
  openPopup() {
    this.displayStyle = "block";
    
  }
  closePopup() {
    this.displayStyle = "none";
    this.accept();
  }

  closePopupreject(){
    this.displayStyle = "none";
    this.reject();
  }


  examinerTable=false;
  btnexamin="";
  examinerForm=false;
  examinerasForm =false;
  examinerasLoad(){
    this.examasForm = this.formBuilder.group({
      name :[''],
      designation :[''],
      phone :[''],
      faculty :[''],
     
    })
    this.examinerasForm=true;
    this.examinerTable=false;
    const currentYear = new Date().getFullYear().toString();
 
  this.firebaseService.getprosalList(currentYear).subscribe(res => {
    this.Proposal = res.map(e => {
      this.propid=e.payload.doc.id;
      return {
        id: e.payload.doc.id,
       
        ...e.payload.doc.data() as {}


      } as Proposal ;
    })
  })
  }


  onSubmitasexam(){

  }

  examinerLoad(){
    this.examinerTable=true;
    this.supervisorregform = false;
    this.examinertable =false;
    this.supervisortable =false;
    this.isSignedIn = false;
    this.isSignedUp = false;
    this.lognav=false;
    this.navdash=false;
    this.studentregform=false;
    this.header = true;
    this.navdash=true;
    this.studenttable=false;
    this.studenteditformload=false;
    this.stiles = false;
    this.btnstudent=""
    this.textcolor = "white"
    this.btnexamin="#e2a500"
    this.btndashbord='';

    this.firebaseService.getExamList().subscribe(res => {
      this.Examiner = res.map(e => {
        return {
          id: e.payload.doc.id,
          ...e.payload.doc.data() as {}
  
  
        } as Examiner;
      })
    })

  }


  examinerFormload(){
    this.btnstudent=""
    this.textcolor = "white"
    this.examinerForm=true;
    this.examinerTable=false;
    this.supervisorregform = false;
    this.examinertable =false;
    this.supervisortable =false;
    this.isSignedIn = false;
    this.isSignedUp = false;
    this.lognav=false;
    this.navdash=false;
    this.studentregform=false;
    this.header = true;
    this.navdash=true;
    this.studenttable=false;
    this.studenteditformload=false;
    this.stiles = false;
    this.btnexamin="#e2a500";
    this.btndashbord='';

   

    this.examForm = this.formBuilder.group({
      name :[''],
      designation :[''],
      phone :[''],
      faculty :[''],
     
    })
  }

  onSubmitexam(){ 
    
    this.firebaseService.onsendserviceexam(this.examForm.value);

    }

filterConditionprop(Prop:any){
  return Prop.title.toLowerCase().indexOf(this.searchText.toLowerCase()) != -1;

}

filterConditionex(ex:any){
  return ex.name.toLowerCase().indexOf(this.searchText.toLowerCase()) != -1;
}

ti:any;
Proposalc:any;
getcurrenttitle(event:any){
  console.log('JJJ:'+event.target.value);
   this.ti=event.target.value;
   this.firebaseService.getpropde(this.ti).subscribe(res => {
    this.Proposalc = res.map(e => {
      this.propid=e.payload.doc.id;
      return {
        id: e.payload.doc.id,
       
        ...e.payload.doc.data() as {}


      } as Proposal ;
    })
  });
}

selectedexam:any;
getcurrentexam(event:any){
  this.selectedexam=event.target.value;
 // this.assignex(this.selectedexam);
}
assignex(){
  this.firebaseService.assignex(this.selectedexam);
}
}

