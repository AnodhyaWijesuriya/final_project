import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { Observable } from 'rxjs';
import { AngularFireAuth } from '@angular/fire/compat/auth';
import { AngularFirestore } from '@angular/fire/compat/firestore';
import { Student,Proposal, Examiner } from './user.model';
import FirestoreFullTextSearch from 'firestore-full-text-search';


@Injectable({
  providedIn: 'root'
})
export class NameService {

  data:any;
  isLoggedIn=false;


  constructor(private http:HttpClient,public auth:AngularFireAuth,private angularFirestore: AngularFirestore ) {

    
   }




  onsendservice(student:Student){
    return new Promise<any>((resolve, reject) => {
      this.angularFirestore.collection('Student').add(student).then(response => {
        console.log(response)
      }, error => reject(error));
    });
    }



    arrq:any|string[];
    onsendservice2(pro:Proposal){
      return new Promise<any>((resolve, reject) => {
        this.angularFirestore.collection('Proposal').add(pro).then(response => {
          console.log(response)
        }, error => reject(error));
      });
      }
    getUserList() {
      console.log("user set"+this.angularFirestore.collection('Student').snapshotChanges());
      return this.angularFirestore.collection('Student').snapshotChanges();
        
    }

    getprosalList1(){
      console.log("user set"+this.angularFirestore.collection('Proposal').snapshotChanges());
      return this.angularFirestore.collection('Proposal').snapshotChanges();
    }

    getprosalList(year:any){
     // console.log("user set"+this.angularFirestore.collection('Proposal').collection(year).snapshotChanges());
      return this.angularFirestore.collection('Proposal').doc(year).collection(year).snapshotChanges();
    }

    getprosalListload(intake:any){
      return this.angularFirestore.collection('Proposal',ref=>ref.where('intake','==',intake)).snapshotChanges();
    }

    i:any;
    ab:any;
    getrelated(year:any,currenttitle:any){
      console.log('currenttitle',currenttitle);
    //  this.ab= this.angularFirestore.collection("Proposal").doc(year).collection(year,ref=>ref.where('keywords',"array-contains",currenttitle)).snapshotChanges();
    //  console.log(this.ab);
    // return (this.angularFirestore.collection("Proposal").doc(year).collection(year ,ref=>ref.where('abstract',"array-contains",currenttitle)).snapshotChanges());
    //for(this.i=0;this.i<currenttitle.length;this.i++){
    return (this.angularFirestore.collection("Proposal",ref=>ref.where('abstract','array-contains-any',currenttitle)).snapshotChanges());
   // }
  }

    

    getrelatedkey(year:any,currenttitle:any){
      console.log('currenttitle',currenttitle);
     // this.ab= this.angularFirestore.collection("Proposal",ref=>ref.where('keywords',"array-contains",currenttitle || 'janani')).snapshotChanges();
     // console.log(this.ab);
     // return (this.angularFirestore.collection("Proposal").doc(year).collection(year ,ref=>ref.where('abstract',"array-contains",currenttitle)).snapshotChanges());
     //for(this.i=0;this.i<currenttitle.length;this.i++){
     return (this.angularFirestore.collection("Proposal",ref=>ref.where('keywords','array-contains-any',currenttitle)).snapshotChanges());
   // }
  }
fullTextSearch:any;



 newmasg:any
 sendtoapp(msg:any){
    console.log(msg);
     this.newmasg=msg;
    return this.newmasg.subscribe;
 }

 sendpropstatus(propstatus:any,propid:any,disablestatus:boolean){
   console.log(propstatus,propid,disablestatus);
  return this.angularFirestore.collection('Proposal').doc(propid).update({
    status :propstatus,
    disablestatus: disablestatus
  });
 }

 getpropde(title:any){
  return this.angularFirestore.collection("Proposal",ref=>ref.where('title',"==",title)).snapshotChanges();
 }

 getrelateddetails(title:any){
   console.log('gggggg',title);
  return (this.angularFirestore.collection("Proposal",ref=>ref.where('title','==',title)).snapshotChanges());
 }

 getgroupinfo(){
 
  return this.angularFirestore.collection('Groupinfo').snapshotChanges();
}

deleteproposal(proposalid:any){
  this.angularFirestore.collection("Proposal").doc(proposalid).delete();
}
getbudget(){
 
  return this.angularFirestore.collection('Budget').snapshotChanges();
}

getethical(){
 
  return this.angularFirestore.collection('Ethical').snapshotChanges();
}

displaymonth(month:any){
  return this.angularFirestore.collection('monthlyprogress').doc(month).collection(month).snapshotChanges();
}
}
