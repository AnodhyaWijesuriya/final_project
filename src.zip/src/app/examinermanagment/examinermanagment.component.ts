import { Component, OnInit } from '@angular/core';
import { NameService } from './name.service';
import { Examiner,Supervisoras,Faculty,Proposal } from './user.model';
import { AngularFirestore } from '@angular/fire/compat/firestore';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';


@Component({
  selector: 'ExaminermanagmentComponent',
  templateUrl: './Examinermanagment.component.html',
  styleUrls: ['./Examinermanagment.component.css']
})
export class ExaminermanagmentComponent implements OnInit {

  btnExaminer: string | undefined;
  dashComponent: boolean | undefined;
  superComponent:boolean | undefined;
  Examinertable: boolean | undefined;
  Examiner: Examiner[] | undefined;
  searchText: string = "";
  Examcmp:any;
  btnSup:string = "";
  proposalComponent:any;
  textcolor = "white";
  public ExaminerForm: FormGroup |any;
  ExamassignForm:FormGroup |any;
  Examinerdob: any;
  Examregform:any;
  pwd:any;
  cpwd:any;
  studentComponent:any;
  displayStyle: string | undefined;
  deletusermodel: boolean | undefined;
  Examid: any;
  ExamEditForm: FormGroup | any;
  Exameditformload: boolean | undefined;
  firstname:any;
  lastname:any;
  studentid:any;
  phonenumber:any;
  emailaddress:any;
  homeaddress:any;
  sintake:any;
  sfaculty:any;
  sdepartment:any;
  epassword:any;
  econpw:any;
  aemail:any;
  snumber:any;
  loadExameditform: boolean | undefined;
  examinerasForm: any;
  asform: boolean | undefined;
  examiner: any;
  examinerid: any;
  Eaminername: string | undefined;
  proposal: any;
  student: any;
  supervisor: any;
  recordid: any;
  userprofile: any;
  btnprofile:string="";
  guidlineComponent:any;
  aemailaddress:any;
  apassword: any;
  aconpw: any;
  constructor(public firebaseService: NameService,public formBuilder: FormBuilder,private angularFirestore: AngularFirestore
    ) { }
 
   ngOnInit(): void {
     this.btnExaminer="#e2a500";
     this.dashComponent=false;
     this.proposalComponent=false;
     this.studentComponent=false;
     this.superComponent=false;
     this.guidlineComponent=false;
     //this.studentsection()
     this.Examinertable=true;
     this.Examcmp=true;
     this.textcolor = "white";
    this.Exameditformload=false;
    this.loadExameditform=false;
    
     this.firebaseService.getUserList().subscribe(res => {
       this.Examiner = res.map(e => {
         return {
           id: e.payload.doc.id,
           ...e.payload.doc.data() as {}
   
   
         } as Examiner;
       })
     })
    // this.filterCondition(Examiner);
   }
 
   dashboardsection(){
     this.dashComponent=true;
     this.proposalComponent=false;
     this.studentComponent=false;
     this.Examinertable=false;
     this.Examcmp=false;
     this.Examregform=false;
     this.Exameditformload=false;
     this.loadExameditform=false;
     this.examinerasForm=false;
     this.asform=false;
     this.superComponent=false;
      this.guidlineComponent=false;
   }
 
   studentsection(){
    this.dashComponent=false;
    this.proposalComponent=false;
    this.studentComponent=true;
     this.Examinertable=false;
     this.Examcmp=false;
     this.Examregform=false;
     this.studentComponent=true;
     this.Exameditformload=false;
     this.loadExameditform=false;
     this.examinerasForm=false;
     this.asform=false;
     this.superComponent=false;
     this.guidlineComponent=false;
   }

   loadSupervisor(){
    this.dashComponent=false;
    this.proposalComponent=false;
    this.btnSup="";
    this.Examcmp=false;
    this.Examinertable=false;
    this.Examregform=false;
    this.Exameditformload=false;
    this.loadExameditform=false;
    this.studentComponent=false;
    this.examinerasForm=false;
    this.superComponent=true;
    this.asform=false;
    this.guidlineComponent=false;
   }
 
   proposalsection(){
    this.dashComponent=false;
    this.Examinertable=false;
    this.Examcmp=false;
    this.Examregform=false;
    this.proposalComponent=true;
    this.Exameditformload=false;
    this.loadExameditform=false;
    this.asform=false;
    this.studentComponent=false;
    this.superComponent=false;
    this.guidlineComponent=false;
   }
 
   loadExaminer(){
    this.dashComponent=false;
    this.btnExaminer="#e2a500";
    this.btnSup="";
    this.Examinertable=true;
    this.Examregform=false;
    this.Exameditformload=false;
    this.loadExameditform=false;
    this.asform=false;
    this.Examcmp=true;
    this.proposalComponent=false;
    this.superComponent=false;
    this.examinerasForm=false;
    this.guidlineComponent=false;
   }

   loadprofile(){
    this.dashComponent=false;
    this.Examinertable=false;
    this.Examcmp=false;
    this.Examregform=false;
    this.proposalComponent=false;
    this.Exameditformload=false;
    this.loadExameditform=false;
    this.asform=false;
    this.studentComponent=false;
    this.superComponent=false;
   this.userprofile=true;
   this.btnExaminer="";
   this.guidlineComponent=false;
  
  }
 
   loadguid(){
     this.dashComponent=false;
    this.Examinertable=false;
    this.Examcmp=false;
    this.Examregform=false;
    this.proposalComponent=false;
    this.Exameditformload=false;
    this.loadExameditform=false;
    this.asform=false;
    this.studentComponent=false;
    this.superComponent=false;
   this.userprofile=false;
   this.btnExaminer="";
    this.guidlineComponent=true;
   }
 
   faculty:any;
   loadExaminerform(){
    this.Examregform=true;
    this.Examinertable=false;
 
    this.Exameditformload=false;
    this.loadExameditform=false;
    
  
 this.ExaminerForm = this.formBuilder.group({
   
    fname :['',[Validators.required]],
    lname :['',[Validators.required]],
    gender :['',[Validators.required]],
    phone :['',[Validators.required,Validators.pattern("^[0-9]*$")]],
    email:['',[Validators.required,Validators.email]],
    aemail:['',[Validators.required,Validators.email]],
    birthday:['',[Validators.required]],
    home:['',[Validators.required]],
    faculty:['',[Validators.required]],
    department:['',[Validators.required]],
    password:['',[Validators.required,Validators.minLength(6)]],
    conp :['',[Validators.required]],

  })

  this.firebaseService.getfaculty().subscribe(res => {
    this.faculty = res.map(e => {
      return {
        id: e.payload.doc.id,
        ...e.payload.doc.data() as {}
  
  
      } as Faculty;
    })
  })

   }

   facultyname:any;
  dep:any;
  getfacultyevent(event:any){
     this.facultyname= event.target.value;
    
 
     this.firebaseService.filterdep(this.facultyname).subscribe(res => {
       this.dep = res.map(e => {
         return {
           id: e.payload.doc.id,
           ...e.payload.doc.data() as {}
     
     
         } as Faculty;
       })
     })
  }

   deleteModalDialog(user:any){
    this.Examid=  user.id;
    console.log(user.id);
    this.deletusermodel=true;
    this.Examinertable=false;
    this.displayStyle = "block";

  }
  
  deleteExaminer(){
    this.firebaseService.deleteExaminer(this.Examid);
    this.deletusermodel=false;
    this.Examinertable=true;
    this.displayStyle = "none";
   }
  
  closeModalDialog(){
    
    this.deletusermodel=false;
    this.Examinertable=true;
    this.displayStyle = "none";
  }

 loadExamedit(Examiner:any){
  this.Examregform=false;
  this.Examid=  Examiner.id; 
  this.Examinertable=false;
  this.loadExameditform=true;
  
 this.ExamEditForm = this.formBuilder.group({
   
    fname :['',[Validators.required]],
    lname :['',[Validators.required]],
 
    phone :['',[Validators.required,Validators.pattern("^[0-9]*$")]],
    email:['',[Validators.required,Validators.email]],
    aemail:['',[Validators.required,Validators.email]],
    home:['',[Validators.required]],
    faculty:['',[Validators.required]],
    department:['',[Validators.required]],
    apassword:['',[Validators.required]],
    aconpw:['',[Validators.required]],
   

  })
  this.firstname=Examiner.fname;
 // console.log('student firstname::',this.Examiner);
  this.lastname=Examiner.lname;
  this.Examid=Examiner.id;
  this.phonenumber=Examiner.phone;
  this.emailaddress=Examiner.email;
  this.aemailaddress=Examiner.aemail;
  this.homeaddress= Examiner.home;
  this.sfaculty=Examiner.faculty;
  this.epassword=Examiner.password;
  this.sdepartment=Examiner.department;
  this.econpw=Examiner.conp;
 }

 filterCondition(Exa: any) {
  console.log(Exa.num);
  return Exa.fname.toLowerCase().indexOf(this.searchText.toLowerCase()) != -1;
  
  }

  get fname(){
    return this.ExaminerForm.get('fname');
  }
 
  get lname(){
   return this.ExaminerForm.get('lname');
 }
 
  get password(){
   return this.ExaminerForm.get('password');
 }
 
 get conp(){
   return this.ExaminerForm.get('conp');
 }
 
 get email(){
   return this.ExaminerForm.get('email');
 }
 
 get birthday(){
   return this.ExaminerForm.get('birthday');
 }
 
 get home()
 {
   return this.ExaminerForm.get('home');
 }
 
 get num(){
   return this.ExaminerForm.get('num');
 }
 
 get phone(){
   return this.ExaminerForm.get('phone');
 }


  onSubmit(){ 
    
   
     
      this.firebaseService.onsendservice(this.ExaminerForm.value);
      this.loadExaminer();
    }
  
  
  
  studentdob :any;
  SendDataonChange(event: any) {
   this.Examinerdob=event.target.value;
   }

   onEditSubmit(){

  
    this.Examregform=false;
    this.Examinertable=false;
    this.Exameditformload=false;
    
this.firebaseService.updateExaminer(this.ExamEditForm.value, this.Examid);
this.Examinertable=true;
this.loadExameditform=false;
  }

  Supervisoraslist:any;
  loadassignexaminer(){
    this.examinerasForm=true;
    this.Examinertable=false;
    this.loadExameditform=false;
    this.firebaseService.acceptproposallist().subscribe(res => {

      this.Supervisoraslist= res.map(e => {
        console.log(e.payload.doc.data());
        return {
          id: e.payload.doc.id,
          ...e.payload.doc.data() as {}
  
  
        } as Proposal;
      })
    })
  }

  selectedLevel:any;
  supervisorasId:any;
  studentname:any;
  getdetails(proposal:any){
    this.asform=true;
    this.examinerasForm=false;
    this.Examinertable=false;
    this.loadExameditform=false;
    this.recordid=proposal.id;
    this.studentname=proposal.student;
    this.firebaseService.supervisorlist().subscribe(res => {
      this.Supervisoraslist= res.map(e => {
        this.supervisorasId=e.payload.doc.id
        return {
          
          id: e.payload.doc.id,
          ...e.payload.doc.data() as {}
  
  
        } as Supervisoras;
      })
    })

    this.firebaseService.getUserList().subscribe(res => {
      this.Examiner = res.map(e => {
        return {
          id: e.payload.doc.id,
          ...e.payload.doc.data() as {}
  
  
        } as Examiner;
      })
    })

    this.ExamassignForm = this.formBuilder.group({
   
      title :['',[Validators.required]],
      sname :['',[Validators.required]],
      supervisor:['',[Validators.required]],
      examiner:['',[Validators.required]]
     
  
    })

 this.proposal=proposal.title;
 // console.log('student firstname::',this.supervisor);
  this.student=proposal.student;
  this.supervisor=proposal.supervisor;
  this.examiner=this.examiner;

  //this.proposalI=proposal.id; 
  }

  getexam(event:any){
    this.examiner=event.target.value;
    console.log('vvvvv',this.selectedLevel.id)
    this.examinerid=this.selectedLevel.id;
    this.Eaminername=this.selectedLevel.fname + ' '+this.selectedLevel.lname;
  }

  onAsSubmit(){
    this.asform=false;
   // this.examinerasForm=true;
    this.Examinertable=false;
    this.loadExameditform=false;
    
    this.firebaseService.assignex(this.ExamassignForm.value,this.recordid,this.examinerid,this.student);
    this.loadassignexaminer();
  }

}
