import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ProposalmanagmentComponent } from './proposalmanagment.component';

describe('ProposalmanagmentComponent', () => {
  let component: ProposalmanagmentComponent;
  let fixture: ComponentFixture<ProposalmanagmentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ProposalmanagmentComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ProposalmanagmentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
