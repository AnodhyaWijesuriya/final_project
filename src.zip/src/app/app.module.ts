import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {NameService} from './name.service';
import { AppComponent } from './app.component';
import {HttpClientModule} from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AngularFireModule } from "@angular/fire/compat";
//import {Auth } from "@angular/fire/auth";
import { environment } from 'src/environments/environment';
import { FormsModule } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';

import { AngularFireStorageModule } from '@angular/fire/compat/storage';
import {MatDialogModule} from '@angular/material/dialog';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { PopUpComponent } from './pop-up/pop-up.component';
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { SidebarComponent } from './sidebar/sidebar.component';
import { StudentmanagmentComponent } from './studentmanagment/studentmanagment.component';
import { ProposalmanagmentComponent } from './proposalmanagment/proposalmanagment.component';
import { SupervisormanagmentComponent } from './supervisormanagment/supervisormanagment.component';
import { ExaminermanagmentComponent } from './examinermanagment/examinermanagment.component';
import { UserprofileComponent } from './userprofile/userprofile.component';
import { GuidelineComponent } from './guideline/guideline.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegisterComponent,
    DashboardComponent,
    SidebarComponent,
    StudentmanagmentComponent,
    ProposalmanagmentComponent,
    SupervisormanagmentComponent,
    ExaminermanagmentComponent,
    UserprofileComponent,
    GuidelineComponent,
    
  ],
  imports: [
    AppRoutingModule,
    BrowserModule,
    HttpClientModule,
   // Auth,
    AngularFireModule.initializeApp(environment.firebaseConfig),
    FormsModule,
    ReactiveFormsModule,
    AngularFireStorageModule,
    MatDialogModule,
    BrowserAnimationsModule,
    NgbModule
  ],
  providers: [
    NameService,
   // PopUpComponent
    
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
