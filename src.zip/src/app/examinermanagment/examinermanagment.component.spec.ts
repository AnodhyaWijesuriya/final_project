import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ExaminermanagmentComponent } from './examinermanagment.component';

describe('ExaminermanagmentComponent', () => {
  let component: ExaminermanagmentComponent;
  let fixture: ComponentFixture<ExaminermanagmentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ExaminermanagmentComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ExaminermanagmentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
