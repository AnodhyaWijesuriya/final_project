import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { AngularFirestore } from '@angular/fire/compat/firestore';
import { FormBuilder } from '@angular/forms';
import { Proposal,Student,Group,Budget,Ethical,Monthlyprogrees } from './user.model';
import { NameService } from './name.service';


@Component({
  selector: 'ProposalmanagmentComponent',
  templateUrl: './proposalmanagment.component.html',
  styleUrls: ['./proposalmanagment.component.css']
})
export class ProposalmanagmentComponent implements OnInit {
  dashComponent: any;
  Proposal: Proposal[] | undefined;
  propid: string | undefined;
  searchText: string = "";
  btndashbord:string =""
  btnstudent:string=""
  btnproposal:string=""
  btnsupervisor:string=""
  btnguide:string=""
  btnexam:string="";
  proposaltable:any;
  proposaltablesearch:any;
  stComponent:any;
  superComponent:any;
  guidlineComponent:any;
  userprofile:any;

  studenttable: any;
  textcolor = "white"
  relatedo:boolean =false; 
  relatedprop:boolean=false;

  
  studentcmp: boolean | undefined;
  Student: Student[] | undefined;
  proposalComponent: boolean | undefined;
  search: any;
  relatedproposaltable: boolean | undefined;
  pp: string | undefined;
  Proposalx:any;
  Proposaly:any;
  examinerComponent:any;
  filedetails: any;
  btnprofile: string="";
  Ethicaltable:any;
  Budgettable:any;
  Budget:any;
  Ethical:any;
  ptitle:any;
  pnum:any;
  pstudent:any;
  punable:any;
  pwork:any;
  pproblem:any;
  pplanned:any;
  monthpro:any;
  pdate:any;
  pid:any;
  pmonth:any;
  pdone:any;
  ppro:any;
  pcomment:any;
  progress:any;
  progresstable:any;
  month:any;
  monthproview:any;

  constructor(public firebaseService: NameService,public formBuilder: FormBuilder,private http:HttpClient,private angularFirestore: AngularFirestore) { }

  ngOnInit(): void {
    this.dashComponent=false;
    this.proposaltable=true;
    this.studentcmp=true;
    this.btnproposal="#e2a500";
    const currentYear = new Date().getFullYear().toString();
    this.examinerComponent=false;
    this.proposalComponent=false;
    this.dashComponent=false;
    this.superComponent=false;
    this.guidlineComponent=false;
    this.Ethicaltable=false;
    this.Budgettable=false;
    this.progresstable=false;
    this.monthproview=false;
  /*this.firebaseService.getprosalList1().subscribe(res => {
    this.Proposal = res.map(e => {
      this.propid=e.payload.doc.id;
      return {
        id: e.payload.doc.id,
       
        ...e.payload.doc.data() as {}


      } as Proposal ;
    })
  })*/

  /*this.firebaseService.getprosalListload().subscribe(res => {
    this.Proposal = res.map(e => {
      this.propid=e.payload.doc.id;
      return {
        id: e.payload.doc.id,
       
        ...e.payload.doc.data() as {}


      } as Proposal ;
    })
  })*/

  console.log('this.Proposal',this.Proposal);

  this.textcolor = "white"


 
    
  }

  filterConditionprop(Prop:any){
    return Prop.title.toLowerCase().indexOf(this.searchText.toLowerCase()) != -1;
  
  }

  dashboardsection(){
    
    this.btndashbord="#e2a500";
    this.btnstudent="";
    this.btnproposal="";
    this.btnsupervisor="";
    this.btnguide="";
    this.btnexam="";
    this.proposaltable=false;
    this.dashComponent=true;
    this.studenttable=false;
    this.proposaltable=false;
    this.studentcmp=false;
    this.stComponent=false;
    this.superComponent=false;
    this.examinerComponent=false;
    this.proposalComponent=false;
    this.proposaltablesearch=false;
    this.relatedprop=false;
    this.relatedproposaltable=false;
    this.userprofile=false;
    this.guidlineComponent=false;
    this.Ethicaltable=false;
    this.Budgettable=false;
    this.progresstable=false;
    this.monthproview=false;
  }

  studentsection(){
    this.proposaltablesearch=false;
    this.relatedprop=false;
    this.relatedproposaltable=false;
    this.proposaltable=false;
   this.studentcmp=false;
   this.studenttable=false;
   this.dashComponent=false;
   this.btndashbord="";
   this.btnstudent="#e2a500";
   this.btnproposal="";
   this.btnsupervisor="";
   this.btnguide="";
   this.btnexam="";
   this.proposalComponent=false;
   this.stComponent=true;
   this.superComponent=false;
   this.examinerComponent=false;
   this.userprofile=false;
   this.guidlineComponent=false;
   this.Ethicaltable=false;
   this.Budgettable=false;
   this.progresstable=false;
   this.monthproview=false;
   this.firebaseService.getUserList().subscribe(res => {
   this.Student = res.map(e => {
      return {
        id: e.payload.doc.id,
        ...e.payload.doc.data() as {}


      } as Student;
    })
  })

  }

  proposalsection(){
   this.btndashbord="";
   this.btnstudent="";
   this.btnproposal="#e2a500";
   this.btnsupervisor="";
   this.btnguide="";
   this.btnexam="";
   this.studenttable=false;
  // this.proposalComponent=true;
   this.dashComponent=false;
   this.proposaltable=true;
   this.proposaltablesearch=false;
   this.relatedprop=false;
   this.relatedproposaltable=false;
   this.studentcmp=false;
   this.stComponent=false;
   this.superComponent=false;
   this.examinerComponent=false;
   this.studentcmp=true;
   this.userprofile=false;
   this.guidlineComponent=false;
   this.intake='';
   this.Ethicaltable=false;
   this.Budgettable=false;
   this.progresstable=false;
   this.monthproview=false;

  /* this.firebaseService.getprosalList1().subscribe(res => {
    this.Proposal = res.map(e => {
      this.propid=e.payload.doc.id;
      return {
        id: e.payload.doc.id,
       
        ...e.payload.doc.data() as {}


      } as Proposal ;
    })
  })*/


  this.firebaseService.getprosalListload(this.intake).subscribe(res => {
    this.Proposal = res.map(e => {
      this.propid=e.payload.doc.id;
      return {
        id: e.payload.doc.id,
       
        ...e.payload.doc.data() as {}


      } as Proposal ;
    })
  })

  }

  loadsupervisor(){
   this.btndashbord="";
   this.btnstudent="";
   this.btnproposal="";
   this.btnsupervisor="#e2a500";
   this.btnguide="";
   this.btnexam=""; 
   this.superComponent=true;
   this.proposalComponent=false;
   this.dashComponent=false;
   this.examinerComponent=false;
   this.relatedproposaltable= false;
   this.proposaltablesearch=false;
   this.relatedprop=false;
   this.relatedproposaltable=false;
   this.proposaltable=false;
   this.studentcmp=false;
   this.userprofile=false;
   this.guidlineComponent=false;
   this.Ethicaltable=false;
   this.Budgettable=false;
   this.progresstable=false;
   this.monthproview=false;
  }

  loadguid(){
    this.btndashbord="";
    this.btnstudent="";
    this.btnproposal="";
    this.btnsupervisor="";
    this.btnguide="#e2a500"; 
    this.btnexam="";
    this.btnprofile="";
    this.proposaltable=false;
    this.examinerComponent=false;
    this.proposalComponent=false;
    this.dashComponent=false;
    this.stComponent=false;
    this.superComponent=false;
    this.proposaltablesearch=false;
    this.relatedprop=false;
    this.relatedproposaltable=false;
    this.userprofile=false;
    this.studentcmp=false;
   this.guidlineComponent=true;
   this.Ethicaltable=false;
    this.Budgettable=false;
    this.progresstable=false;
    this.monthproview=false;
  }

  loadexaminer(){
   this.btndashbord="";
   this.btnstudent="";
   this.btnproposal="";
   this.btnsupervisor="";
   this.btnguide=""; 
   this.btnexam="#e2a500";
   this.examinerComponent=true;
   this.proposalComponent=false;
   this.dashComponent=false;
   this.stComponent=false;
   this.superComponent=false;
   this.proposaltablesearch=false;
   this.relatedprop=false;
   this.relatedproposaltable=false;
   this.userprofile=false;
   this.guidlineComponent=false;
   this.proposaltable=false;
   this.studentcmp=false;
   this.Ethicaltable=false;
   this.Budgettable=false;
   this.progresstable=false;
   this.monthproview=false;
  }

  loadprofile(){
    this.btndashbord="";
   this.btnstudent="";
   this.btnproposal="";
   this.btnsupervisor="";
   this.btnguide=""; 
   this.btnexam="";
   this.btnprofile="";
   this.proposaltable=false;
   this.examinerComponent=false;
   this.proposalComponent=false;
   this.dashComponent=false;
   this.stComponent=false;
   this.superComponent=false;
   this.proposaltablesearch=false;
   this.relatedprop=false;
   this.relatedproposaltable=false;
   this.userprofile=true;
   this.studentcmp=false;
   this.guidlineComponent=false;
   this.Ethicaltable=false;
   this.Budgettable=false;
   this.progresstable=false;
   this.monthproview=false;
  }


 i:any;
 currentproposal:any;
 keywords:any;
 keywordstodb:any

 passval(keywords:any){
        console.log('oooooo',keywords); 
        this.keywordstodb=keywords;
 }
  searchtitle(title:any){
    this.search=title;
    var splitted = title.split(" ");
    console.log(splitted.length);
    this.relatedproposaltable= true;
    this.proposaltable=false;
    this.relatedprop=true;
    this.studenttable=false;
    this.proposaltablesearch=false;
    this.btndashbord=""
    this.btnstudent=""
    this.Ethicaltable=false;
    this.Budgettable=false;
    this.proposaltable=false;
    this.progresstable=false;
    this.monthproview=false;
    this.firebaseService.getrelateddetails(this.search).subscribe(res => {
      
      
      this.currentproposal = res.map(e => {
        
       // this.keywords=e.payload.doc.data('key')
       this.propid=e.payload.doc.id;
        return {
         
          id: e.payload.doc.id,
         
          ...e.payload.doc.data() as {}
          
  
        } as Proposal;
      })
      console.log(this.currentproposal[0].status);
      this.passval(this.currentproposal[0].keywords);
      this.searchrelatedtopics(this.currentproposal[0].keywords);
    })
 

    

   
  
  }

searchrelatedtopics(keywordstodb:any){
  this.firebaseService.getrelated(this.intake,keywordstodb).subscribe(res => {
      
      
    this.Proposalx = res.map(e => {
      this.relatedo=true;
      this.pp='res';
     
      return {
        id: e.payload.doc.id,
        ...e.payload.doc.data() as {}


      } as Proposal;
    })
  
  })





    this.firebaseService.getrelatedkey(this.intake,keywordstodb).subscribe(res => {
      
      
      this.Proposaly = res.map(e => {
     
        return {
          id: e.payload.doc.id,
          ...e.payload.doc.data() as {}
  
  
        } as Proposal;
      })
    
    })
}




  propintake:any;
  searchbyintake(){
   
    this.firebaseService.getprosalListload(this.intake).subscribe(res => {
      this.propintake = res.map(e => {
        this.propid=e.payload.doc.id;
        return {
          id: e.payload.doc.id,
         
          ...e.payload.doc.data() as {}
  
  
        } as Proposal ;
      })
    })
    this.proposaltablesearch=true;
    this.proposaltable=false;
    this.getgroupinfo();
    this.Ethicaltable=false;
    this.Budgettable=false;
    this.progresstable=false;
    this.monthproview=false;
  }

  intake:any
  getintake(event: any){
     {
      this.intake=event.target.value;
      console.log('this.intake',this.intake);
      this.searchbyintake();


      }
    
  }

  displayStyle = "none";
  col="none";
  acc:any;
  rej:any;
  openPopupacc() {
    this.displayStyle = "block";
    this.relatedproposaltable=false;
    this.acc=true;
    this.rej=false;
    this.Ethicaltable=false;
    this.Budgettable=false;
    this.progresstable=false;
    this.monthproview=false;
    
  }
  openPopuprej() {
    this.displayStyle = "block";
    this.relatedproposaltable=false;
    this.rej=true;
    this.acc=false;
    this.Ethicaltable=false;
    this.Budgettable=false;
    this.progresstable=false;
    this.monthproview=false;
  }
 

  closePopup(){
    this.displayStyle = "none";
    this.relatedproposaltable=true;
    this.rej=false;
    this.acc=false;
    this.Ethicaltable=false;
    this.Budgettable=false;
    this.progresstable=false;
    this.monthproview=false;
  }

  acceptpro:any;
  disablestatus:boolean =true;
  accept(){ 
  this.displayStyle = "none";   
  this.acceptpro="Accept";
  this.disablestatus=true;
  this.sendpropstatus();
  this.proposaltablesearch=true;
  this.rej=false;
  this.acc=false;
  this.Ethicaltable=false;
  this.Budgettable=false;
  this.progresstable=false;
  this.monthproview=false;
  }
 
  reject(){
   this.acceptpro="Reject";
   this.disablestatus=true;
   this.sendpropstatus();
   this.proposaltablesearch=true;
   this.Ethicaltable=false;
   this.Budgettable=false;
   this.progresstable=false;
   this.monthproview=false;
   
   this.rej=false;
   this.acc=false;
  }

  sendpropstatus(){
    this.firebaseService.sendpropstatus(this.acceptpro,this.propid,this.disablestatus);
  }

  backtotable(){
    this.relatedproposaltable= false;
    this.proposaltable=true;
    this.relatedprop=false;
    this.studenttable=false;
    this.proposaltablesearch=false;
    this.Ethicaltable=false;
    this.Budgettable=false;
    this.progresstable=false;
    this.monthproview=false;
  }

  groupinfo:any;

  getgroupinfo(){
    this.firebaseService.getgroupinfo().subscribe(res => {
      this.groupinfo = res.map(e => {
        return {
          id: e.payload.doc.id,
          ...e.payload.doc.data() as {}
  
  
        } as Group;
      })
    })
  }

  deleteproposal:any;
  proid:any;
  loaddelete(proposal:any){
    this.deleteproposal=true;
    this.proposaltablesearch=false;
    this.proid=proposal.id;
    this.Ethicaltable=false;
    this.Budgettable=false;
    this.progresstable=false;
    this.monthproview=false;
  }


  deletetitle(){
    this.firebaseService.deleteproposal(this.proid);
    this.deleteproposal=false;
    this.proposaltablesearch=true;
    this.Ethicaltable=false;
    this.Budgettable=false;
    this.progresstable=false;
    this.monthproview=false;
  }

  nodelete(){
    this.deleteproposal=false;
    this.proposaltablesearch=true;
    this.Ethicaltable=false;
    this.Budgettable=false;
    this.progresstable=false;
    this.monthproview=false;
  }

  loadbudgets(){
    this.Budgettable=true;
    this.relatedproposaltable= false;
    this.proposaltable=false;
    this.relatedprop=false;
    this.studenttable=false;
    this.proposaltablesearch=false;
    this.progresstable=false;
    this.monthproview=false;

    this.firebaseService.getbudget().subscribe(res => {
      this.Budget = res.map(e => {
        return {
          id: e.payload.doc.id,
          ...e.payload.doc.data() as {}
  
  
        } as Budget;
      })
    })

  }

  loadethical(){
    this.Ethicaltable=true;
    this.relatedproposaltable= false;
    this.proposaltable=false;
    this.relatedprop=false;
    this.studenttable=false;
    this.proposaltablesearch=false;
    this.progresstable=false;
    this.monthproview=false;

    this.firebaseService.getethical().subscribe(res => {
      this.Ethical = res.map(e => {
        return {
          id: e.payload.doc.id,
          ...e.payload.doc.data() as {}
  
  
        } as Ethical;
      })
    })

  }

  getmonthpro(event:any){
      
        
    this.month=event.target.value;
    console.log('this.intake',this.month);
    this.loadmonthlyprogress();

  
}

loadmonthlyprogress(){
  this.progresstable=true;
  this.Ethicaltable=false;
  this.relatedproposaltable= false;
  this.proposaltable=false;
  this.relatedprop=false;
  this.studenttable=false;
  this.proposaltablesearch=false;
  this.monthproview=false;

  this.firebaseService.displaymonth(this.month).subscribe(res => {
    this.progress = res.map(e => {
     
      return {
        id: e.payload.doc.id,
        ...e.payload.doc.data() as {}


      } as Monthlyprogrees;
    })
  })


  
}

viewmore(progress:any){
  this.monthproview=true;
  this.progresstable=false;
  this.Ethicaltable=false;
  this.relatedproposaltable= false;
  this.proposaltable=false;
  this.relatedprop=false;
  this.studenttable=false;
  this.proposaltablesearch=false;

    this.ptitle=progress.title;
    this.pnum=progress.num;
    this.pstudent=progress.student;
    this.pwork=progress.work;
    this.pproblem=progress.problem;
    this.punable=progress.unable;
    this.pplanned=progress.planned;
    this.pdate=progress.date;
    this.pid=progress.id;
    this.pmonth=progress.month;
    this.pdone=progress.done;
    this.ppro=progress.progress;
    this.pcomment=progress.comment;

  }
} 
