import { Component, OnInit } from '@angular/core';
import { AngularFirestore } from '@angular/fire/compat/firestore';
import { NameService } from './name.service';
import { Admin } from './user.model';
import { AngularFireAuth } from '@angular/fire/compat/auth';

@Component({
  selector: 'UserprofileComponent',
  templateUrl: './userprofile.component.html',
  styleUrls: ['./userprofile.component.css']
})
export class UserprofileComponent implements OnInit {

  dashComponent:any;
  examinerComponent:any;
  studentComponent:any;
  proposalComponent:any;
  supervisorComponent:any;
  btnprofile="#e2a500";
  profilecmp:any;
  profileform:any;
  currentuser:any;
  useremail:any;
  currentemail:any;
userdetails:any;
profileformedit:any;
guidlineComponent:any;
  constructor(public firebaseService: NameService,public auth:AngularFireAuth) { }

  ngOnInit(): void {
    this.dashComponent=false;
    this.examinerComponent=false;
    this.btnprofile="#e2a500";
    this.profilecmp=true;
    this.profileform=true;
    this.profileformedit=false;
    this.guidlineComponent=false;
   // this.loaddata();
   this.auth.currentUser.then(response => {
    console.log('current user'+response?.email);
    this.currentemail=response?.email;
    //this.userdetails=this.angularFirestore.collection('Admin',ref=>ref.where('email',"==",this.currentemail)).snapshotChanges();
    console.log('jjjj'+this.currentemail);
    this.view(this.currentemail);
  });
     
  }

  view(email:any)
{
  this.useremail=email;
  console.log(this.useremail);
  this.loaddata(this.useremail);
}
loaddata(useremail:any){
    this.firebaseService.getUser(useremail).subscribe(res => {
      this.currentuser = res.map(e => {
        console.log('vvvvvvvvvv'+e.payload.doc.data());
        return {
          id: e.payload.doc.id,
          ...e.payload.doc.data() as {}
    
    
        } as Admin;
      })
    })
  }

  dashboardsection(){
    this.dashComponent=true;
    this.examinerComponent=false;
    this.guidlineComponent=false;
    this.btnprofile="";
    this.profilecmp=false;
    this.profileform=false;
  }

  studentsection(){
   this.dashComponent=false;
   this.studentComponent=true;
   this.guidlineComponent=false;
   this.btnprofile="";
   this.profilecmp=false;
   this.profileform=false;
  }

  proposalsection(){
   this.dashComponent=false;
   this.proposalComponent=true;
   this.guidlineComponent=false;
   this.btnprofile="";
   this.profilecmp=false;
  }

  loadsupervisor(){
    this.dashComponent=false;
    this.supervisorComponent=true;
    this.guidlineComponent=false;
    this.btnprofile="";
    this.profilecmp=false;
  }

  loadguid(){
    this.guidlineComponent=true;
    this.dashComponent=false;
    this.examinerComponent=false;
    this.profilecmp=false;
    this.profileform=false;
    this.profileformedit=false;
    this.btnprofile="";
  }

  loadexaminer(){
    this.dashComponent=false;
    this.examinerComponent=true;
    this.guidlineComponent=false;
    this.btnprofile="";
    this.profilecmp=false;
    this.profileform=false;
  }

  loadprofile(){
    this.btnprofile="#e2a500";
    this.dashComponent=false;
    this.examinerComponent=false;
    this.guidlineComponent=false;
    this.profilecmp=true;
    this.profileform=true;
    this.profileformedit=false;
  }
 userid:any;
  loadeditform(userid:any){
    console.log(userid);
    this.userid=userid;
    this.profilecmp=true;
    this.profileform=false; 
    this.profileformedit=true;
  }

  editprofile(fname:string,lname:string,phone:string,address:string,faculty:string,department:string){
    this.firebaseService.editUser(this.userid,fname,lname,phone,address,faculty,department);
    this.profileform=true; 
    this.profileformedit=false;
  }
}
