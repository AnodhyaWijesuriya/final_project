import { Component, Inject, OnInit ,Output,EventEmitter} from '@angular/core';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import { NameService } from '../name.service';
import { Student } from '../user.model';
import { AppComponent} from '../app.component';

@Component({
  selector: 'app-pop-up',
  templateUrl: './pop-up.component.html',
  styleUrls: ['./pop-up.component.css']
})
export class PopUpComponent implements OnInit {
  msg="hello";
  @Output() event = new EventEmitter<any>();
 
  studentid:any;
  studentname:any;
  constructor(@Inject(MAT_DIALOG_DATA) public data:any, public firebaseService: NameService,) {
   this.studentid=data.studentlistid;
   this.studentname=data.studentname;
   }

  ngOnInit(): void {
 
  }

  
  deletestudent(){
    this.firebaseService.deleteStudent(this.studentid);
  //  this.appc.studentsection();
  }


  deletecancel(){
 //  this.appc.studentsection();
 //this.event.emit(this.msg);

 return this.firebaseService.sendtoapp(this.msg);
 
  }
 
}
