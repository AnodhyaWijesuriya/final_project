import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { Observable } from 'rxjs';
import { AngularFireAuth } from '@angular/fire/compat/auth';
import { AngularFirestore } from '@angular/fire/compat/firestore';
import { Guideline,FileUpload } from './user.model';
import FirestoreFullTextSearch from 'firestore-full-text-search';
import { setgroups } from 'process';
import { notStrictEqual } from 'assert';
import { AngularFireStorage } from '@angular/fire/compat/storage';
import { AngularFireDatabase, AngularFireList } from '@angular/fire/compat/database';
import { finalize } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class NameService {

  data:any;
  isLoggedIn=false;


  constructor(private db: AngularFireDatabase,private http:HttpClient,public auth:AngularFireAuth,private angularFirestore: AngularFirestore,private storage: AngularFireStorage ) {

    
   }


guid:any;
  insertguideline(phase:any,guidelines:any,setps:any,dates:any,notice:any,documents:any){
    this.guid={
      phase :phase,
      guideline: guidelines,
      steps:setps,
      date:dates,
      notice:notice
     
    }
    this.angularFirestore.collection('Guideline').add(this.guid);
  }
  updateguideline(docid:any,guidelines:any,setps:any,dates:any,notice:any,documents:any){
  return this.angularFirestore.collection('Guideline').doc(docid).update({
   
    guideline: guidelines,
    steps:setps,
    date:dates,
    notice:notice
   

  });}
  

    getguideList(phase:any) {
      console.log("user set"+this.angularFirestore.collection('Student').snapshotChanges());
      return this.angularFirestore.collection('Guideline',ref=>ref.where('phase','==',phase)).snapshotChanges();
        
    }

    getprosalList1(){
      console.log("user set"+this.angularFirestore.collection('Proposal').snapshotChanges());
      return this.angularFirestore.collection('Proposal').snapshotChanges();
    }

    getprosalList(year:any){
     // console.log("user set"+this.angularFirestore.collection('Proposal').collection(year).snapshotChanges());
      return this.angularFirestore.collection('Proposal').doc(year).collection(year).snapshotChanges();
    }

    getprosalListload(intake:any){
      return this.angularFirestore.collection('Proposal',ref=>ref.where('intake','==',intake)).snapshotChanges();
    }

    i:any;
    ab:any;
    getrelated(year:any,currenttitle:any){
      console.log('currenttitle',currenttitle);
    //  this.ab= this.angularFirestore.collection("Proposal").doc(year).collection(year,ref=>ref.where('keywords',"array-contains",currenttitle)).snapshotChanges();
    //  console.log(this.ab);
    // return (this.angularFirestore.collection("Proposal").doc(year).collection(year ,ref=>ref.where('abstract',"array-contains",currenttitle)).snapshotChanges());
    //for(this.i=0;this.i<currenttitle.length;this.i++){
    return (this.angularFirestore.collection("Proposal",ref=>ref.where('abstract','array-contains-any',currenttitle)).snapshotChanges());
   // }
  }

    

    getrelatedkey(year:any,currenttitle:any){
      console.log('currenttitle',currenttitle);
     // this.ab= this.angularFirestore.collection("Proposal",ref=>ref.where('keywords',"array-contains",currenttitle || 'janani')).snapshotChanges();
     // console.log(this.ab);
     // return (this.angularFirestore.collection("Proposal").doc(year).collection(year ,ref=>ref.where('abstract',"array-contains",currenttitle)).snapshotChanges());
     //for(this.i=0;this.i<currenttitle.length;this.i++){
     return (this.angularFirestore.collection("Proposal",ref=>ref.where('keywords','array-contains-any',currenttitle)).snapshotChanges());
   // }
  }
fullTextSearch:any;



 newmasg:any
 sendtoapp(msg:any){
    console.log(msg);
     this.newmasg=msg;
    return this.newmasg.subscribe;
 }

 sendpropstatus(propstatus:any,propid:any,disablestatus:boolean){
   console.log(propstatus,propid,disablestatus);
  return this.angularFirestore.collection('Proposal').doc(propid).update({
    status :propstatus,
    disablestatus: disablestatus
  });
 }

 getpropde(title:any){
  return this.angularFirestore.collection("Proposal",ref=>ref.where('title',"==",title)).snapshotChanges();
 }

 getrelateddetails(title:any){
   console.log('gggggg',title);
  return (this.angularFirestore.collection("Proposal",ref=>ref.where('title','==',title)).snapshotChanges());
 }

 private basePath = '/uploads';
  
 pushFileToStorage(fileUpload: FileUpload): Observable<number | undefined> {
   const filePath = `${this.basePath}/${fileUpload.file.name}`;
   const storageRef = this.storage.ref(filePath);
   const uploadTask = this.storage.upload(filePath, fileUpload.file);
   uploadTask.snapshotChanges().pipe(
     finalize(() => {
       storageRef
       storageRef.getDownloadURL().subscribe(downloadURL => {
         fileUpload.url = downloadURL;
         fileUpload.name = fileUpload.file.name;
         this.saveFileData(fileUpload);
        
         this.onsendservice(fileUpload.url );
       });
     })
   ).subscribe();
   return uploadTask.percentageChanges();
 }

 private saveFileData(fileUpload: FileUpload): void {
  this.db.list(this.basePath).push(fileUpload);
}

onsendservice(url:any){
  
  

  this.angularFirestore.collection('docs').add({
    
    url:url
    
})
.then(res => {
    console.log(res);
    
})
.catch(e => {
    console.log(e);
})


}

getstudentList(){
 return this.angularFirestore.collection('Student').snapshotChanges();
}

getstudentListname(studentemailaddress:any){
  return this.angularFirestore.collection('Student',ref=>ref.where('email',"==",studentemailaddress)).snapshotChanges();
 }

}
