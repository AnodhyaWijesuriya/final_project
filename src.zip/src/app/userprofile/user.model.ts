export class Admin {
  id:string |any;
  fname :string | any;
  lname :string | any;
  email:string | any;
  address:string | any;
  faculty:string | any;
  department:string | any;
  password:string | any;
 
}




