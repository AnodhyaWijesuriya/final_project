import { Component, OnInit } from '@angular/core';
import { RegisterService } from './register.service';

@Component({
  selector: 'RegisterComponent',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  error1: string | undefined;
  signmail: string | undefined;
  message: string | undefined;
  navdash: boolean = false;
  header: boolean = false;
  studenttable: boolean = false;
  stiles: boolean = false;
  studentregform: boolean = false;
  isSignedUp: boolean = false;
  isSignedIn: boolean = false;
  lognav: boolean = false;
  fonts: string | undefined;
  disableSignUp:boolean=false;
  loginComponent:boolean=false;
  dashComponent:boolean=false;

  constructor(public firebaseService: RegisterService) { }

  ngOnInit(): void {
    this.disableSignUp=true;
  }

  async onSignUp(email:string,password:string,firstname:string,lastname:string,address:string,department:string,faculty:string,confirmpw:string,phone:string){
  
    this.error1=""
    this.signmail = email;
    console.log(password +'  '+confirmpw)
    if(password===confirmpw){
        
    
    
    this.firebaseService.sigup(email, password).then(() => {
     
      this.message = "you are registered"
      this.navdash=false;
        this.header = false;
        this.studenttable=false;
        this.stiles=false;
        this.studentregform=false;
        this.isSignedUp = false;
        this.disableSignUp=false;
        this.dashComponent=true;
      this.error1="";
      this.firebaseService.registertodb(email, password,firstname,lastname,address,department,faculty,phone);
    }).catch((_error: any) => {
      this.error1 = "Password should be at least 6 characters";
      this.isSignedUp = true;
    })
    if(this.firebaseService.isLoggedIn)
    this.isSignedIn=false
      this.lognav=false;
      //this.navdash=true;
    //this.isSignedUp = true;
      this.studentregform = false;
   }
  
  else{
    alert("not match");
    this.isSignedUp = true;
  }
}

   SiginAgain() {
    this.disableSignUp=false;
    this.loginComponent=true;
  }

}
