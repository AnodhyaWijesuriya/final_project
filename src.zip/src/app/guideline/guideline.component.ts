import { Component, OnInit } from '@angular/core';
import { NameService } from './name.service';
import { Guideline,FileUpload,Student } from './user.model';
import { Twilio } from 'twilio';
import emailjs, { EmailJSResponseStatus } from '@emailjs/browser';

@Component({
  selector: 'GuidelineComponent',
  templateUrl: './guideline.component.html',
  styleUrls: ['./guideline.component.css']
})
export class GuidelineComponent implements OnInit {


  constructor(public firebaseService: NameService) { }


    dashComponent:any;
    examinerComponent:any;
    studentComponent:any;
    proposalComponent:any;
    supervisorComponent:any;
    userprofile:any;
    btnguidline="#e2a500";
    textcolor="white";
    guidcmp:any;
    profileform:any;
    currentuser:any;
    useremail:any;
    currentemail:any;
  userdetails:any;
  profileformedit:any;
  guidelinetable:any;
  guide:any;
  guidelineform:any;
  percentage = 0;
    ngOnInit(): void {
      //this.dashComponent=false;
      //this.examinerComponent=false;
      this.btnguidline="#e2a500";
      this.guidcmp=true;
      this.guidelinetable=true;
      this.textcolor="white";
      this.guidelineform=false;
    
   /*   this.firebaseService.getguideList(this.phase).subscribe(res => {
        this.guide = res.map(e => {
          return {
            id: e.payload.doc.id,
            ...e.payload.doc.data() as {}
      
      
          } as Guideline;
        })
      })*/
   
    }
    accountSid = 'ACe84d0a77fffb0800028fa88a0a95b521';
    authToken = '3d4ac15d9109bdd40005b4b27f18e403';
    twilioNumber = '';
    myNumber = '0779243067';
    
    
   /* sendsms(){
      if (accountSid && authToken && myNumber && twilioNumber) {
        const client = new Twilio(accountSid, authToken);
      
        client.messages
          .create({
            from: twilioNumber,
            to: myNumber,
            body: "You just sent an SMS from TypeScript using Twilio!",
          })
          .then((message) => console.log(message.sid));
      } else {
        console.error(
          "You are missing one of the variables you need to send a message"
        );
      }
    }*/

  
    p1:any;
    p2:any;
    p3:any;
    p4:any;
  p5:any;
  guiId:any;
    guidelineeditform:any;
    loadguideedit(gui:any){
      
      
       
      this.guiId=gui.id;
      this.guidelineeditform=true;
      this.guidelinetable=false;
      this.guidelineform=false;
      this.p1=gui.phase;
      this.p2=gui.guideline;
      this.p3=gui.steps;
      this.p4=gui.date;
      this.p5=gui.notice; 
   
   
      
    }
    editform(guidelines:any,steps:any,date:any,notices:any){
      this.firebaseService.updateguideline( this.guiId,guidelines,steps,date,notices,this.documents);        
      this.dashComponent=false;
      this.examinerComponent=false;
      this.btnguidline="#e2a500";
      this.guidcmp=false;
      this.guidelinetable=true;
      this.guidelineform=false;
      this.guidelineeditform=false;
    }
    
    dashboardsection(){
      this.dashComponent=true;
      this.examinerComponent=false;
      this.studentComponent=false;
      this.supervisorComponent=false;
      this.proposalComponent=false;
      this.btnguidline="";
      this.profileform=false;
      this.guidcmp=false;
      this.userprofile=false;
      this.mailform=false;
      this.guidelinetable=false;
    }
  
    studentsection(){
      this.dashComponent=false;
      this.examinerComponent=false;
      this.dashComponent=false;
      this.studentComponent=true;
      this.supervisorComponent=false;
      this.proposalComponent=false;
     this.btnguidline="";
     this.guidcmp=false;
     this.profileform=false;
     this.userprofile=false;
     this.mailform=false;
     this.guidelinetable=false;
    }
  
    proposalsection(){
      this.dashComponent=false;
      this.examinerComponent=false;
      this.dashComponent=false;
      this.studentComponent=false;
      this.supervisorComponent=false;
      this.proposalComponent=true;
     this.btnguidline="";
     this.guidcmp=false;
     this.userprofile=false;
     this.mailform=false;
     this.guidelinetable=false;
    }
  
    loadsupervisor(){
      this.dashComponent=false;
      this.examinerComponent=false;
      this.dashComponent=false;
      this.studentComponent=false;
      this.supervisorComponent=true;
      this.proposalComponent=false;
      this.btnguidline="";
      this.guidcmp=false;
      this.userprofile=false;
      this.dashComponent=false;
      this.examinerComponent=false;
      this.btnguidline="#e2a500";
      this.mailform=false;
      
      this.guidelinetable=false;
      this.guidelineform=false;
      this.guidelinetable=false;
      this.uploadnormalform=false;
      this.guidelinetable=false
    }
  
    loadguid(){
      this.dashComponent=false;
      this.examinerComponent=false;
      this.dashComponent=false;
      this.studentComponent=false;
      this.supervisorComponent=false;
      this.btnguidline="#e2a500";
      this.guidcmp=true;
      this.profileform=false;
      this.userprofile=false;
      this.mailform=false;
      this.guidelinetable=true;
    }
  
    loadexaminer(){
      this.dashComponent=false;
      this.examinerComponent=true;
      this.dashComponent=false;
      this.studentComponent=false;
      this.supervisorComponent=false;
      this.proposalComponent=false;
      this.btnguidline="";
      this.guidcmp=false;
      this.profileform=false;
      this.userprofile=false;
      this.guidelinetable=false;
      this.mailform=false;
      this.guidelinetable=false;
    }
  
    loadprofile(){
      this.btnguidline="";
      this.dashComponent=false;
      this.examinerComponent=false;
      this.dashComponent=false;
      this.studentComponent=false;
      this.supervisorComponent=false;
      this.proposalComponent=false;
      this.guidcmp=false;
      this.userprofile=true;
      this.mailform=false;
      this.guidelinetable=false;
    }
 
    phase:any;
    documents:any;
    uploadnormalform:any;
    getphase(event: any)
      {
       this.phase=event.target.value;

         
      this.firebaseService.getguideList(this.phase).subscribe(res => {
        this.guide = res.map(e => {
          return {
            id: e.payload.doc.id,
            ...e.payload.doc.data() as {}
      
      
          } as Guideline;
        })
      })
      }

      onsubmitmile(guidelines:any,steps:any,date:any,notices:any){
        this.firebaseService.insertguideline(this.phase,guidelines,steps,date,notices,this.documents);        
        this.dashComponent=false;
        this.examinerComponent=false;
        this.btnguidline="#e2a500";
        this.guidcmp=false;
        this.guidelinetable=true;
        this.guidelineform=false;
      }

      loadguidlineform(){
      this.dashComponent=false;
      this.examinerComponent=false;
      this.btnguidline="#e2a500";
      this.guidcmp=true;
      this.guidelinetable=false;
      this.guidelineform=true;
      }

      loadnormalform(){
        this.uploadnormalform=true;
        this.guidcmp=true;
        this.guidelinetable=false;
      }  
      
      backtotable(){
      this.dashComponent=false;
      this.examinerComponent=false;
      this.btnguidline="#e2a500";
      this.guidcmp=true;
      this.guidelinetable=false;
      this.guidelineform=false;
      this.guidelinetable=true;
      this.uploadnormalform=false;
      this.mailform=false;
      }
      selectedFiles?: FileList;
      currentFileUpload?: FileUpload;
      selectFile(event: any): void {
        this.selectedFiles = event.target.files;
      }

      upload(): void {
    
        var abstract:string[]; 
        var keywords:string[]; 
       
    

    
     
        if (this.selectedFiles) {
          const file: File | null = this.selectedFiles.item(0);
          this.selectedFiles = undefined;
          if (file) {
            this.currentFileUpload = new FileUpload(file);
            this.firebaseService.pushFileToStorage(this.currentFileUpload).subscribe(
              percentage => {
                this.percentage = Math.round(percentage ? percentage : 0);
              },
              error => {
                console.log(error);
              }
            );
          }
        }
    
      }

      mailform:any;
      studentemail:any;
      loadmailform(){
        this.mailform=true;
        this.btnguidline="#e2a500";
        this.guidcmp=true;
        this.guidelinetable=false;
        this.textcolor="white";
        this.guidelineform=false;

        this.firebaseService.getstudentList().subscribe(res => {
          this.studentemail = res.map(e => {
            return {
              id: e.payload.doc.id,
              ...e.payload.doc.data() as {}
        
        
            } as Student;
          })
        })
      }

      public sendEmail(e: Event) {
        e.preventDefault();
        emailjs.sendForm('service_9dclyy7', 'template_uwcc10c', e.target as HTMLFormElement, '3S7D4IelcuP9CvIjh')
          .then((result: EmailJSResponseStatus) => {
            console.log(result.text);
          }, (error) => {
            console.log(error.text);
          });

          this.mailform=false;
          this.btnguidline="#e2a500";
          this.guidcmp=true;
          this.guidelinetable=true;
          this.textcolor="white";
          this.guidelineform=false;

      }

      studentemailaddress:any;
      studentname:any;
      getemail(event:any){
        this.studentemailaddress=event.target.value;
        console.log(this.studentemailaddress);
        this.firebaseService.getstudentListname(this.studentemailaddress).subscribe(res => {
          this.studentname = res.map(e => {
            return {
              id: e.payload.doc.id,
              ...e.payload.doc.data() as {}
        
        
            } as Student;
          })
        })

      }
}
