import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { Observable } from 'rxjs';
import { AngularFireAuth } from '@angular/fire/compat/auth';
import { AngularFirestore } from '@angular/fire/compat/firestore';
import { Student,Proposal,Supervisor,Supervisoras} from './user.model';
import FirestoreFullTextSearch from 'firestore-full-text-search';

@Injectable({
  providedIn: 'root'
})
export class NameService {

  data:any;
  isLoggedIn=false;


  constructor(private http:HttpClient,public auth:AngularFireAuth,private angularFirestore: AngularFirestore ) {

    
   }

   


  onsendservice(supervisor:Supervisor){
    return new Promise<any>((resolve, reject) => {
      this.angularFirestore.collection('Supervisor').add(supervisor).then(response => {
        console.log(response)
      }, error => reject(error));
    });
    }
i=1;
  onsendservice2(supervisor:Supervisoras,supervisorid:any,cosupervisorid:any,proposalId:any,supervisorname:any,cosupervisorname:any,scount:any,supervisoremail:any){
    if(scount==undefined){
       scount=0;
    }
    console.log('supervisorname:',supervisorname);
    this.angularFirestore.collection('Supervisor').doc(supervisorid).update({
      status:'Assign',
      scount:1+scount
      
  
    });

    this.angularFirestore.collection('Supervisor').doc(cosupervisorid).update({
      status:'Assign',
      coscount:1
      
  
    });

    this.angularFirestore.collection('Proposal').doc(proposalId).update({
      superstatus:'Assigned',
      supervisor:supervisorname,
      supervisoremail:supervisoremail,
      superdisablestatus:true,
      cosupervisorname:cosupervisorname,

  
    });

    /*return new Promise<any>((resolve, reject) => {
      this.angularFirestore.collection('Supervisoras').add(supervisor).then(response => {
        console.log(response)
      }, error => reject(error));
    });*/

   

    }

 

    getUserList() {
      console.log("user set"+this.angularFirestore.collection('Supervisor').snapshotChanges());
      return this.angularFirestore.collection('Supervisor').snapshotChanges();
        
    }

    getStudentList() {
      console.log("user set"+this.angularFirestore.collection('Supervisor').snapshotChanges());
      return this.angularFirestore.collection('Student').snapshotChanges();
        
    }

    getrequestList() {
     // console.log("user set"+this.angularFirestore.collection('Supervisor').snapshotChanges());
      return this.angularFirestore.collection('requestdoc').snapshotChanges();
        
    }

    getUserList2() {
      console.log("user set"+this.angularFirestore.collection('Supervisor').snapshotChanges());
      return  this.angularFirestore.collection('Supervisor',ref=>ref.where('stype',"==","S")).snapshotChanges();
        
    }

    getcoUserList2() {
      console.log("user set"+this.angularFirestore.collection('Supervisor').snapshotChanges());
      return  this.angularFirestore.collection('Supervisor',ref=>ref.where('stype',"==","Co")).snapshotChanges();
        
    }

fullTextSearch:any;

updateSupervisor(supervisor:Supervisor,supervisorid:any){
  return this.angularFirestore.collection('Supervisor').doc(supervisorid).update({
    fname :supervisor.fname,
    lname :supervisor.lname,
  
    phone :supervisor.phone,
    email:supervisor.email,
    
    home:supervisor.home,
   

  });

}

deleteSupervisor(sid:any){
  return this.angularFirestore.collection('Supervisor').doc(sid).delete();
  
  
 }
 newmasg:any
 sendtoapp(msg:any){
    console.log(msg);
     this.newmasg=msg;
    return this.newmasg.subscribe;
 }

 

 assignex(ex:any){
  return this.angularFirestore.collection('Examiner',ref=>ref.where('name',"==",ex)).add({
    status :'Assign'

  });
 }

 //assign supervisor
 getprosalList(){
  return this.angularFirestore.collection('Proposal',ref=>ref.where('status',"==","Accept")).snapshotChanges();
 }

 getstudent(ti:any){
  return this.angularFirestore.collection('Proposal',ref=>ref.where('title',"==",ti)).snapshotChanges();
 }

 onsendserviceass(supervisorid:any,selectedpro:any){
  this.angularFirestore.collection('Proposal').doc(selectedpro).update({
    status:"1"
   

  });
   this.angularFirestore.collection('Supervisor').doc(supervisorid).update({
    status:"1"
   

  });

   return this.angularFirestore.collection('SupervisorAssign').doc(selectedpro).update({
    status:"1",
    supervisor:supervisorid.aemail,
    proposal:selectedpro.title,
    student:selectedpro.student
   

  });

  }

  //get selected supervisor id
  /*getsupervisorid() {
    //console.log("user set"+this.angularFirestore.collection('Supervisor',ref=>ref.where('status',"==","Accept")).snapshotChanges());
    return this.angularFirestore.collection('Supervisor',ref=>ref.where('fname',"==",)).snapshotChanges();
      
  }*/

  getUserListas() {
    //console.log("user set"+this.angularFirestore.collection('Supervisor',ref=>ref.where('status',"==","Accept")).snapshotChanges());
    return this.angularFirestore.collection('Supervisor',ref=>ref.where('status',"==","1")).snapshotChanges();
      
  }

  getfaculty(){
    return this.angularFirestore.collection('Faculty-dep').snapshotChanges();
   }

   filterdep(facultyname:any){
    return this.angularFirestore.collection('Faculty-dep').doc(facultyname).collection(facultyname).snapshotChanges();
   }

   countsupervisor(supervisorname:any){
    return this.angularFirestore.collection('Supervisor',ref=>ref.where('aemail',"==",supervisorname)).snapshotChanges();
   }

   updaterequestsatus(reqid:any){
    this.angularFirestore.collection('requestdoc').doc(reqid).update({
     status:'Accept'

    })
   }

   updaterequestsatus2(reqid:any){
    this.angularFirestore.collection('requestdoc').doc(reqid).update({
     status:'Reject'

    })
   }
}
