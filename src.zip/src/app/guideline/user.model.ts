export class Student {
  id:string |any;
  fname :string | any;
  lname :string | any;
  gender :string | any;
  phone :string | any;
  email:string | any;
  birthday:string | any;
  home:string | any;
  faculty:string | any;
  department:string | any;
  intake:string | any;
  num:string | any;
  password:string | any;
  conp :string | any;
}

export class Proposal{
  id:string|any;
  title:string|any;
  supervisor:string|any;
  student:string|any;
  keywords:any;
  datep:any;
  abstract:any;
  status:any;
  disablestatus:any;
  url:string|any;
}

export class Guideline{
  id:string|any;
  phase:string|any;
  notice:string|any;
  steps:string|any;
  date:string|any;
}
export class FileUpload {
  key!: string;
  name!: string;
  url!: string;
  file: File;
  constructor(file: File) {
    this.file = file;
  }

  
}


